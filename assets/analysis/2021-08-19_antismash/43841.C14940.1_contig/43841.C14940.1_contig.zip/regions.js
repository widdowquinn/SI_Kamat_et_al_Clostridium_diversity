var recordData = [
    {
        "length": 4076,
        "seq_id": "C14940.00001",
        "regions": []
    },
    {
        "length": 12103,
        "seq_id": "C14940.00002",
        "regions": []
    },
    {
        "length": 14862,
        "seq_id": "C14940.00003",
        "regions": []
    },
    {
        "length": 18069,
        "seq_id": "C14940.00004",
        "regions": []
    },
    {
        "length": 23354,
        "seq_id": "C14940.00005",
        "regions": []
    },
    {
        "length": 1914,
        "seq_id": "C14940.00006",
        "regions": []
    },
    {
        "length": 2825,
        "seq_id": "C14940.00007",
        "regions": []
    },
    {
        "length": 10173,
        "seq_id": "C14940.00008",
        "regions": []
    },
    {
        "length": 1629,
        "seq_id": "C14940.00009",
        "regions": []
    },
    {
        "length": 38483,
        "seq_id": "C14940.00010",
        "regions": []
    },
    {
        "length": 4449,
        "seq_id": "C14940.00011",
        "regions": []
    },
    {
        "length": 6340,
        "seq_id": "C14940.00012",
        "regions": []
    },
    {
        "length": 1553,
        "seq_id": "C14940.00013",
        "regions": []
    },
    {
        "length": 23053,
        "seq_id": "C14940.00014",
        "regions": []
    },
    {
        "length": 1456,
        "seq_id": "C14940.00015",
        "regions": []
    },
    {
        "length": 18376,
        "seq_id": "C14940.00016",
        "regions": []
    },
    {
        "length": 14498,
        "seq_id": "C14940.00017",
        "regions": []
    },
    {
        "length": 28380,
        "seq_id": "C14940.00019",
        "regions": []
    },
    {
        "length": 5005,
        "seq_id": "C14940.00020",
        "regions": []
    },
    {
        "length": 22783,
        "seq_id": "C14940.00021",
        "regions": []
    },
    {
        "length": 9013,
        "seq_id": "C14940.00022",
        "regions": []
    },
    {
        "length": 32882,
        "seq_id": "C14940.00023",
        "regions": []
    },
    {
        "length": 11380,
        "seq_id": "C14940.00024",
        "regions": []
    },
    {
        "length": 2220,
        "seq_id": "C14940.00025",
        "regions": []
    },
    {
        "length": 16758,
        "seq_id": "C14940.00026",
        "regions": []
    },
    {
        "length": 11165,
        "seq_id": "C14940.00027",
        "regions": []
    },
    {
        "length": 33483,
        "seq_id": "C14940.00028",
        "regions": []
    },
    {
        "length": 5321,
        "seq_id": "C14940.00030",
        "regions": []
    },
    {
        "length": 12814,
        "seq_id": "C14940.00031",
        "regions": []
    },
    {
        "length": 12773,
        "seq_id": "C14940.00032",
        "regions": []
    },
    {
        "length": 13639,
        "seq_id": "C14940.00033",
        "regions": []
    },
    {
        "length": 5246,
        "seq_id": "C14940.00034",
        "regions": []
    },
    {
        "length": 15548,
        "seq_id": "C14940.00035",
        "regions": []
    },
    {
        "length": 8267,
        "seq_id": "C14940.00036",
        "regions": []
    },
    {
        "length": 24520,
        "seq_id": "C14940.00037",
        "regions": []
    },
    {
        "length": 8502,
        "seq_id": "C14940.00038",
        "regions": []
    },
    {
        "length": 12652,
        "seq_id": "C14940.00039",
        "regions": []
    },
    {
        "length": 32197,
        "seq_id": "C14940.00040",
        "regions": []
    },
    {
        "length": 1103,
        "seq_id": "C14940.00041",
        "regions": []
    },
    {
        "length": 8961,
        "seq_id": "C14940.00042",
        "regions": []
    },
    {
        "length": 12779,
        "seq_id": "C14940.00043",
        "regions": []
    },
    {
        "length": 1116,
        "seq_id": "C14940.00044",
        "regions": []
    },
    {
        "length": 54470,
        "seq_id": "C14940.00045",
        "regions": []
    },
    {
        "length": 19227,
        "seq_id": "C14940.00046",
        "regions": []
    },
    {
        "length": 2027,
        "seq_id": "C14940.00047",
        "regions": []
    },
    {
        "length": 1491,
        "seq_id": "C14940.00048",
        "regions": []
    },
    {
        "length": 14827,
        "seq_id": "C14940.00049",
        "regions": []
    },
    {
        "length": 5842,
        "seq_id": "C14940.00051",
        "regions": []
    },
    {
        "length": 4125,
        "seq_id": "C14940.00052",
        "regions": []
    },
    {
        "length": 19013,
        "seq_id": "C14940.00053",
        "regions": []
    },
    {
        "length": 5115,
        "seq_id": "C14940.00054",
        "regions": []
    },
    {
        "length": 1926,
        "seq_id": "C14940.00055",
        "regions": []
    },
    {
        "length": 1047,
        "seq_id": "C14940.00056",
        "regions": []
    },
    {
        "length": 13422,
        "seq_id": "C14940.00057",
        "regions": []
    },
    {
        "length": 1614,
        "seq_id": "C14940.00058",
        "regions": []
    },
    {
        "length": 37482,
        "seq_id": "C14940.00059",
        "regions": []
    },
    {
        "length": 21241,
        "seq_id": "C14940.00060",
        "regions": []
    },
    {
        "length": 8646,
        "seq_id": "C14940.00061",
        "regions": []
    },
    {
        "length": 14180,
        "seq_id": "C14940.00063",
        "regions": []
    },
    {
        "length": 3337,
        "seq_id": "C14940.00064",
        "regions": []
    },
    {
        "length": 1070,
        "seq_id": "C14940.00065",
        "regions": []
    },
    {
        "length": 10779,
        "seq_id": "C14940.00066",
        "regions": []
    },
    {
        "length": 5916,
        "seq_id": "C14940.00067",
        "regions": []
    },
    {
        "length": 4323,
        "seq_id": "C14940.00068",
        "regions": []
    },
    {
        "length": 3167,
        "seq_id": "C14940.00069",
        "regions": []
    },
    {
        "length": 7968,
        "seq_id": "C14940.00070",
        "regions": []
    },
    {
        "length": 11899,
        "seq_id": "C14940.00071",
        "regions": []
    },
    {
        "length": 34120,
        "seq_id": "C14940.00072",
        "regions": []
    },
    {
        "length": 3215,
        "seq_id": "C14940.00073",
        "regions": []
    },
    {
        "length": 15312,
        "seq_id": "C14940.00074",
        "regions": []
    },
    {
        "length": 1856,
        "seq_id": "C14940.00076",
        "regions": []
    },
    {
        "length": 25724,
        "seq_id": "C14940.00077",
        "regions": []
    },
    {
        "length": 23490,
        "seq_id": "C14940.00078",
        "regions": []
    },
    {
        "length": 1665,
        "seq_id": "C14940.00079",
        "regions": []
    },
    {
        "length": 43735,
        "seq_id": "C14940.00080",
        "regions": []
    },
    {
        "length": 13439,
        "seq_id": "C14940.00081",
        "regions": []
    },
    {
        "length": 3207,
        "seq_id": "C14940.00083",
        "regions": []
    },
    {
        "length": 1598,
        "seq_id": "C14940.00084",
        "regions": []
    },
    {
        "length": 26235,
        "seq_id": "C14940.00085",
        "regions": []
    },
    {
        "length": 8918,
        "seq_id": "C14940.00086",
        "regions": []
    },
    {
        "length": 2745,
        "seq_id": "C14940.00087",
        "regions": []
    },
    {
        "length": 29982,
        "seq_id": "C14940.00088",
        "regions": []
    },
    {
        "length": 2639,
        "seq_id": "C14940.00089",
        "regions": []
    },
    {
        "length": 3698,
        "seq_id": "C14940.00090",
        "regions": []
    },
    {
        "length": 24510,
        "seq_id": "C14940.00091",
        "regions": []
    },
    {
        "length": 9453,
        "seq_id": "C14940.00092",
        "regions": []
    },
    {
        "length": 11418,
        "seq_id": "C14940.00093",
        "regions": []
    },
    {
        "length": 1129,
        "seq_id": "C14940.00094",
        "regions": []
    },
    {
        "length": 11064,
        "seq_id": "C14940.00096",
        "regions": []
    },
    {
        "length": 26952,
        "seq_id": "C14940.00097",
        "regions": []
    },
    {
        "length": 19440,
        "seq_id": "C14940.00098",
        "regions": []
    },
    {
        "length": 7466,
        "seq_id": "C14940.00099",
        "regions": []
    },
    {
        "length": 2756,
        "seq_id": "C14940.00100",
        "regions": []
    },
    {
        "length": 10590,
        "seq_id": "C14940.00101",
        "regions": []
    },
    {
        "length": 1116,
        "seq_id": "C14940.00102",
        "regions": []
    },
    {
        "length": 3046,
        "seq_id": "C14940.00103",
        "regions": []
    },
    {
        "length": 9965,
        "seq_id": "C14940.00104",
        "regions": [
            {
                "start": 1,
                "end": 9965,
                "idx": 1,
                "orfs": [
                    {
                        "start": 310,
                        "end": 900,
                        "strand": -1,
                        "locus_tag": "KGBDKNAJ_01082",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01082</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01082</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 310 - 900,\n (total: 591 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKKHWYDYLWIWSIIYFTLGFFNILFAWLGMIDFLVPVFIAVFGRNKWFCNNLCGRGQLFALLGGKYKCSRNRPTPRFLVSPWFRYGFLAFFMAMFGNMVFQTWLVAAGASGLREALKLFWTFKVPWGWTYTAGMVPDWVAQYSFGFYSLMLTSLLLGLIMMVLYKPRSWCTFCPMGTMTQGICKLGSRGETQDS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKKHWYDYLWIWSIIYFTLGFFNILFAWLGMIDFLVPVFIAVFGRNKWFCNNLCGRGQLFALLGGKYKCSRNRPTPRFLVSPWFRYGFLAFFMAMFGNMVFQTWLVAAGASGLREALKLFWTFKVPWGWTYTAGMVPDWVAQYSFGFYSLMLTSLLLGLIMMVLYKPRSWCTFCPMGTMTQGICKLGSRGETQDS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAAGAAACACTGGTATGACTATCTCTGGATATGGTCCATCATTTATTTTACACTGGGCTTCTTTAATATTTTATTTGCATGGCTTGGAATGATCGATTTTCTTGTGCCTGTTTTTATCGCTGTTTTCGGGAGAAATAAGTGGTTTTGCAACAATCTCTGCGGCCGCGGCCAATTGTTTGCGCTGCTGGGGGGAAAATATAAATGTTCCAGGAACAGGCCGACGCCCCGGTTTCTCGTATCGCCCTGGTTCCGTTACGGTTTTCTGGCCTTTTTCATGGCTATGTTCGGAAATATGGTGTTTCAGACCTGGCTTGTGGCGGCGGGGGCTTCGGGACTCAGGGAGGCGCTCAAACTGTTCTGGACCTTTAAAGTTCCATGGGGCTGGACTTACACCGCAGGAATGGTGCCGGACTGGGTGGCCCAGTACAGCTTCGGGTTCTACAGCCTGATGCTGACATCACTCTTACTTGGCCTGATTATGATGGTTCTCTATAAACCGAGAAGCTGGTGTACTTTCTGTCCGATGGGAACGATGACCCAGGGGATTTGCAAGCTGGGGAGCAGAGGGGAGACGCAGGACAGTTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 897,
                        "end": 1109,
                        "strand": -1,
                        "locus_tag": "KGBDKNAJ_01083",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01083</span></strong><br>\n \n  NAD(P)H-quinone oxidoreductase subunit I, chloroplastic<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01083</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ndhI_1</span><br>\n \n Location: 897 - 1,109,\n (total: 213 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSVKTKRSVSVNLKRCVACGACCKVCPREAIAVSGGCYAAADLEKCVGCGLCEKLCPAGALSILIREAQL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSVKTKRSVSVNLKRCVACGACCKVCPREAIAVSGGCYAAADLEKCVGCGLCEKLCPAGALSILIREAQL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCTGTTAAAACAAAACGAAGTGTATCGGTGAACCTAAAACGATGCGTCGCGTGCGGAGCATGCTGTAAGGTCTGCCCCAGGGAGGCGATCGCGGTATCAGGAGGCTGCTATGCGGCTGCGGATTTGGAGAAGTGCGTCGGCTGCGGTCTGTGTGAAAAGCTGTGCCCGGCCGGTGCGCTCTCGATTCTTATCAGGGAGGCACAGCTATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1356,
                        "end": 2225,
                        "strand": 1,
                        "locus_tag": "KGBDKNAJ_01084",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01084</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01084</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,356 - 2,225,\n (total: 870 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1148:hypothetical protein (Score: 68.3; E-value: 1.8e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSFSENLQYLRKKQNLTQEQFAEQMEVSRQAVSKWESGQSYPEMEKLLQICEQFGCSMDSLIKGDVTEAAKEDSTGYNRHMNRYSIMVSSAVALIIFSVAIIASLDGIVSEAVTSIILFVLIGIAVYILIIAGISHQYYRRRYPDIDNFYTEEQHANFNRIFAIAIASGVSLIVFSLCLNIWLEYTVIPYSEQISGGVFLLCTAVAVGIFTFFGMQKDKYDIGKYNQENRPEAPGKKHLASKLCGVIMLLATALFLFLGLSFDMFRSAAVIYPVAGIFCGIVCLLLSDK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSFSENLQYLRKKQNLTQEQFAEQMEVSRQAVSKWESGQSYPEMEKLLQICEQFGCSMDSLIKGDVTEAAKEDSTGYNRHMNRYSIMVSSAVALIIFSVAIIASLDGIVSEAVTSIILFVLIGIAVYILIIAGISHQYYRRRYPDIDNFYTEEQHANFNRIFAIAIASGVSLIVFSLCLNIWLEYTVIPYSEQISGGVFLLCTAVAVGIFTFFGMQKDKYDIGKYNQENRPEAPGKKHLASKLCGVIMLLATALFLFLGLSFDMFRSAAVIYPVAGIFCGIVCLLLSDK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTTTTTCAGAGAATTTACAATACTTAAGAAAAAAACAAAATTTGACACAGGAGCAGTTTGCCGAACAGATGGAGGTATCGAGACAGGCCGTCTCCAAATGGGAATCAGGCCAGTCTTACCCGGAGATGGAAAAACTGCTTCAGATATGCGAGCAGTTCGGATGTTCCATGGACAGCCTCATCAAAGGCGATGTGACAGAAGCGGCAAAAGAAGATTCGACAGGCTATAACCGCCATATGAACCGCTATTCCATCATGGTTTCCTCTGCCGTTGCCCTGATCATTTTTTCGGTCGCAATCATCGCCTCGCTGGACGGAATCGTAAGCGAAGCCGTTACAAGCATTATCCTGTTCGTATTGATCGGAATTGCCGTATATATCCTGATAATAGCCGGCATCAGCCATCAGTACTACCGCAGGCGTTATCCCGATATCGATAATTTCTACACGGAAGAACAGCATGCCAATTTCAACCGTATTTTTGCAATTGCCATAGCTTCCGGGGTCAGTCTCATTGTTTTTTCTCTCTGCCTGAACATCTGGCTTGAGTACACCGTTATCCCTTATTCTGAGCAGATAAGCGGAGGCGTTTTTCTTCTCTGTACCGCCGTGGCCGTCGGTATTTTCACTTTCTTTGGCATGCAGAAGGACAAATACGACATCGGCAAATATAACCAGGAAAACCGTCCGGAGGCTCCCGGCAAAAAGCACCTGGCGAGCAAGCTGTGCGGCGTCATCATGCTCCTGGCGACAGCTCTCTTCCTGTTCCTCGGCCTTTCATTTGATATGTTCCGGTCCGCAGCCGTCATTTATCCGGTCGCAGGAATCTTCTGCGGTATCGTCTGCCTGCTGCTGAGCGATAAATAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 2336,
                        "end": 2761,
                        "strand": -1,
                        "locus_tag": "KGBDKNAJ_01085",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01085</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01085</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,336 - 2,761,\n (total: 426 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MEKRYADAAIFYAAAAMVFGVFYREFTKFNGFTGKTNLSVMHTHYFLLGMFFFLILMLLEKNFRFSGGEKIGIILTVYHIGLNVTALGFLLRGLTQVWGTELSRGMDASISGLSGVGHIMLGISMILLLLKIRKKTVLEKK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MEKRYADAAIFYAAAAMVFGVFYREFTKFNGFTGKTNLSVMHTHYFLLGMFFFLILMLLEKNFRFSGGEKIGIILTVYHIGLNVTALGFLLRGLTQVWGTELSRGMDASISGLSGVGHIMLGISMILLLLKIRKKTVLEKK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAAAAACGTTATGCGGATGCAGCCATATTCTATGCAGCGGCTGCCATGGTATTCGGTGTGTTTTACAGGGAGTTTACAAAATTTAACGGTTTTACCGGAAAAACTAATTTATCTGTCATGCATACACATTATTTTCTGTTGGGAATGTTTTTCTTTCTCATACTGATGCTGCTTGAAAAGAATTTCCGGTTTTCCGGCGGGGAGAAGATTGGAATAATTCTGACAGTCTATCACATAGGTTTGAATGTCACCGCCCTCGGTTTTCTTTTAAGGGGTCTGACACAGGTATGGGGTACCGAACTCAGCAGGGGGATGGATGCTTCCATATCGGGCCTTTCCGGTGTGGGCCATATTATGCTGGGAATCAGCATGATTCTGTTGTTGCTGAAGATCAGAAAAAAGACGGTCTTAGAAAAAAAGTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 2777,
                        "end": 3454,
                        "strand": -1,
                        "locus_tag": "KGBDKNAJ_01086",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01086</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01086</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,777 - 3,454,\n (total: 678 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAQAIAETVFDILYLGFALITGLTMLTKGKSRIVKMAGWMTALLGAGDSFHLVPRSYALWTTGMEANAAALGIGKFITSVTMTVFYLILYYIWRERYQIRERKTLTGVMWFLACLRIGFCLLPQNEWLSYHQPLSYGILRNIPFAIMGIIIIVIFAAEAGKKADPVFWFMPLAAGLSFGFYLPVVLFSGAVPAVGMLMIPKTLAYVWMIWMARRLYKEETIIRHT&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAQAIAETVFDILYLGFALITGLTMLTKGKSRIVKMAGWMTALLGAGDSFHLVPRSYALWTTGMEANAAALGIGKFITSVTMTVFYLILYYIWRERYQIRERKTLTGVMWFLACLRIGFCLLPQNEWLSYHQPLSYGILRNIPFAIMGIIIIVIFAAEAGKKADPVFWFMPLAAGLSFGFYLPVVLFSGAVPAVGMLMIPKTLAYVWMIWMARRLYKEETIIRHT\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCACAGGCGATTGCTGAAACAGTTTTTGACATTTTATATCTTGGTTTTGCCCTGATAACAGGACTGACTATGCTGACAAAAGGAAAGAGCCGGATCGTAAAAATGGCAGGATGGATGACGGCGCTGCTGGGGGCAGGGGATTCCTTTCATCTGGTACCGCGTTCCTACGCACTTTGGACAACAGGGATGGAAGCAAATGCAGCCGCATTGGGGATTGGGAAATTTATTACGTCTGTCACGATGACGGTTTTTTATCTGATTTTATATTATATCTGGCGTGAGCGTTACCAGATTCGGGAACGTAAGACACTTACCGGTGTAATGTGGTTTTTAGCATGCCTGAGGATTGGATTTTGTCTTCTGCCTCAGAACGAGTGGCTGTCCTATCACCAGCCTCTGTCTTATGGGATACTGCGAAATATCCCATTTGCGATAATGGGAATTATCATTATCGTAATCTTTGCCGCAGAGGCCGGGAAAAAAGCGGATCCGGTGTTCTGGTTTATGCCTTTGGCGGCGGGACTTTCCTTTGGTTTCTACCTGCCCGTCGTATTGTTCAGCGGCGCAGTACCGGCCGTGGGCATGCTGATGATTCCAAAGACACTGGCTTACGTCTGGATGATTTGGATGGCGAGACGGCTTTACAAAGAAGAAACAATAATCAGGCATACATAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 3474,
                        "end": 4073,
                        "strand": -1,
                        "locus_tag": "KGBDKNAJ_01087",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01087</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01087</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,474 - 4,073,\n (total: 600 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MYSIYEHVHLNEKGDDTVRKKDDSLRGALIDYARELAEKEGPEAVNIRSLAGKAGIATGTVYNYFSCKDEILLALTEEYWRKTLADMRAAVTAPSFCGQLEEIFTFLRERIDSSAGMLMHSLGNVRETGQERMESMQEVLEAAMVYRMEQDPGIRSDIWDETFTKRDYARFIMANMMLLLREHPYDFRFFLEIVKRTVY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MYSIYEHVHLNEKGDDTVRKKDDSLRGALIDYARELAEKEGPEAVNIRSLAGKAGIATGTVYNYFSCKDEILLALTEEYWRKTLADMRAAVTAPSFCGQLEEIFTFLRERIDSSAGMLMHSLGNVRETGQERMESMQEVLEAAMVYRMEQDPGIRSDIWDETFTKRDYARFIMANMMLLLREHPYDFRFFLEIVKRTVY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTATAGTATATATGAACATGTTCATTTAAATGAAAAAGGGGATGATACGGTGCGGAAAAAAGACGACAGCCTGAGGGGGGCACTGATTGACTATGCCCGGGAACTGGCGGAGAAAGAGGGGCCTGAGGCAGTCAATATACGCTCTCTGGCCGGGAAAGCCGGGATTGCGACGGGCACGGTATATAATTATTTTTCATGTAAAGACGAAATCCTCCTGGCTCTCACGGAAGAATACTGGAGAAAGACCTTGGCCGATATGAGGGCGGCAGTCACGGCCCCCTCATTCTGCGGGCAGCTGGAGGAAATTTTTACTTTTTTACGGGAGCGTATCGACAGCTCCGCCGGAATGCTGATGCACAGCCTCGGGAATGTCAGGGAGACAGGGCAGGAGAGAATGGAATCCATGCAGGAGGTTCTGGAAGCCGCAATGGTGTATCGGATGGAGCAGGATCCGGGCATACGCAGTGATATCTGGGACGAAACATTTACAAAGAGAGATTATGCCCGTTTTATTATGGCGAATATGATGCTGCTGCTCAGGGAGCATCCATATGATTTCCGGTTTTTTCTGGAAATAGTCAAACGGACCGTTTATTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 4418,
                        "end": 4690,
                        "strand": -1,
                        "locus_tag": "KGBDKNAJ_01088",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01088</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01088</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,418 - 4,690,\n (total: 273 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGTAGWVLYFVFIIGLMYFIAIRPQQKEKKKMQELMAGVAVGDSVLTSSGFYGVIIDMTDDTVIVEFGSNKNCRIPMRKDAIVQVEKPEL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGTAGWVLYFVFIIGLMYFIAIRPQQKEKKKMQELMAGVAVGDSVLTSSGFYGVIIDMTDDTVIVEFGSNKNCRIPMRKDAIVQVEKPEL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGCACAGCGGGCTGGGTACTATATTTTGTCTTTATCATAGGACTTATGTACTTTATTGCGATCAGACCACAGCAGAAGGAAAAGAAAAAAATGCAGGAGCTGATGGCAGGTGTCGCAGTAGGCGACAGCGTTTTAACATCCAGTGGATTTTACGGCGTAATCATCGACATGACAGATGATACGGTTATCGTAGAATTCGGCAGCAACAAGAACTGCCGTATTCCTATGCGCAAGGATGCAATTGTTCAGGTTGAGAAACCGGAACTGTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 4780,
                        "end": 5922,
                        "strand": -1,
                        "locus_tag": "KGBDKNAJ_01089",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01089</span></strong><br>\n \n  Queuine tRNA-ribosyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01089</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">tgt</span><br>\n \n Location: 4,780 - 5,922,\n (total: 1143 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MEYKILYKDGRAKRAEMKTVHGTVQTPVFMNVGTVGAIKGAVSTDDLKEIGTQVELSNTYHLHVRTGDKLIKQFGGLHKFMNWDRPILTDSGGFQVFSLSGLRKIKEEGVYFNSHIDGRKIFMGPEESMQIQSNLGSTIAMAFDECPSSVASREYVQASVDRTTRWLERCREEMKRLNAQPDTVNREQLLFGINQGAIYEDIRIGHAKTISKMELDGYAVGGLAVGETHEEMYRILDAVVPHLPEDKPTYLMGVGTPANILEAVDRGVDFFDCVYPTRNGRHSHVYTNHGKMNLLNAKYELDKKPIEEGCGCPACRSYSRAYIRHLFKAKEMLGMRLCVLHNLYFYNKMMEEIRDAIEHHRYAEYKTAKLAGMMAGEEAK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MEYKILYKDGRAKRAEMKTVHGTVQTPVFMNVGTVGAIKGAVSTDDLKEIGTQVELSNTYHLHVRTGDKLIKQFGGLHKFMNWDRPILTDSGGFQVFSLSGLRKIKEEGVYFNSHIDGRKIFMGPEESMQIQSNLGSTIAMAFDECPSSVASREYVQASVDRTTRWLERCREEMKRLNAQPDTVNREQLLFGINQGAIYEDIRIGHAKTISKMELDGYAVGGLAVGETHEEMYRILDAVVPHLPEDKPTYLMGVGTPANILEAVDRGVDFFDCVYPTRNGRHSHVYTNHGKMNLLNAKYELDKKPIEEGCGCPACRSYSRAYIRHLFKAKEMLGMRLCVLHNLYFYNKMMEEIRDAIEHHRYAEYKTAKLAGMMAGEEAK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAGTATAAGATTCTTTACAAAGACGGACGCGCGAAACGGGCAGAGATGAAAACCGTCCATGGAACTGTCCAGACACCTGTTTTCATGAATGTGGGAACTGTGGGGGCGATAAAGGGAGCCGTATCTACCGACGATCTGAAGGAAATCGGAACACAGGTAGAGTTGTCCAACACCTACCATCTGCACGTGAGAACCGGTGACAAGCTGATTAAGCAGTTTGGCGGACTTCATAAATTCATGAACTGGGACAGGCCGATTCTGACGGATTCCGGCGGTTTTCAGGTATTTTCCCTGTCGGGACTTCGAAAGATAAAGGAAGAGGGCGTTTATTTTAACTCTCATATCGACGGCAGGAAGATATTCATGGGTCCGGAGGAGAGCATGCAGATCCAGTCCAATCTGGGCTCCACAATCGCAATGGCATTTGATGAATGTCCGTCCAGCGTGGCTTCAAGGGAATACGTCCAGGCCTCGGTAGACAGAACCACAAGATGGCTTGAACGCTGCCGGGAAGAGATGAAACGCCTGAATGCTCAGCCGGATACGGTGAACCGTGAGCAGCTCCTCTTTGGAATCAATCAGGGAGCAATTTACGAGGATATCCGCATCGGGCATGCAAAGACAATCAGCAAGATGGAGCTGGACGGCTATGCTGTGGGCGGCCTGGCCGTGGGTGAAACCCATGAGGAGATGTACCGTATCCTCGATGCGGTGGTTCCCCATCTTCCGGAGGATAAGCCTACGTACCTGATGGGGGTCGGAACGCCTGCCAATATTTTAGAGGCGGTGGACCGCGGCGTTGATTTCTTTGACTGCGTGTATCCGACCAGAAACGGCCGGCACAGCCATGTCTATACAAACCATGGCAAGATGAATCTGCTGAATGCAAAATATGAACTGGATAAAAAGCCGATTGAAGAGGGCTGCGGCTGCCCGGCATGCCGTTCCTACAGCAGGGCCTATATAAGACATCTGTTTAAGGCAAAAGAAATGCTCGGGATGCGATTATGTGTATTGCATAATTTATATTTTTATAATAAAATGATGGAAGAGATTCGCGACGCAATCGAACATCACCGTTATGCCGAATATAAGACTGCAAAGCTTGCCGGCATGATGGCCGGAGAGGAAGCAAAATAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 5926,
                        "end": 8082,
                        "strand": -1,
                        "locus_tag": "KGBDKNAJ_01090",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01090</span></strong><br>\n \n  Protein translocase subunit SecDF<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01090</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">secDF_1</span><br>\n \n Location: 5,926 - 8,082,\n (total: 2157 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKNKKGKSLIGLLLLLVAVGIFGYFGYSTMGAIKLGLDLAGGVSITYQAKEANPSSEDMADTIYKLQQRVQNYSTEAEVYQEGSNRINVDIPGVSDANAILQELGKPGSLVFLDSEFNQVLDGKQVSSAKAGMDDSSGVKEYVVALTFNEEGTKAFADATTKGVGKPIYIVYDGQPISAPNVKEPITGGQCRIDGMGSFEEAENLAATIRIGSLSLELEELRSNVVGAKLGQEAISTSLKAGAIGFGIVVVFMIFAYLIPGLAASIALCLYVGLILVLLAAFEVTLTLPGVAGIILSIGMAVDANVIIFTRIKEEIGMGKTVKSAIKTGFAKALSAIIDGNVTTLIAAAVLFWRGSGTVKGFASTLAIGIILSMFTALFVTKFALYCLFEAGLQDAKYYGVKKDTKVRPFLRYRKLCFAVSGVLILAGFAAMGINSASGGSILNYSMEFRGGTSTNVTFNEDMSLDRISSEVVPVVEKITGEAGTQTQKVAGTNEVIIKTRTLSVDEREELDQALVDTFGVDQEKITADSISGAISKEMKQDAVIAVVIATICMLLYIWFRFSNITFAASAVLALVHDVLVVVTFYAVFKWSVGSTFIACMLTIVGYSINATIVIFDRIRENMKLKKHTQTVEDVVNLSISQTLTRSINTSLTTFIMVFVLFLMGVSSIREFALPLMVGIVCGTYSSVCLTGSMWYLFNQKKEQKAAGERAAKTKKEK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKNKKGKSLIGLLLLLVAVGIFGYFGYSTMGAIKLGLDLAGGVSITYQAKEANPSSEDMADTIYKLQQRVQNYSTEAEVYQEGSNRINVDIPGVSDANAILQELGKPGSLVFLDSEFNQVLDGKQVSSAKAGMDDSSGVKEYVVALTFNEEGTKAFADATTKGVGKPIYIVYDGQPISAPNVKEPITGGQCRIDGMGSFEEAENLAATIRIGSLSLELEELRSNVVGAKLGQEAISTSLKAGAIGFGIVVVFMIFAYLIPGLAASIALCLYVGLILVLLAAFEVTLTLPGVAGIILSIGMAVDANVIIFTRIKEEIGMGKTVKSAIKTGFAKALSAIIDGNVTTLIAAAVLFWRGSGTVKGFASTLAIGIILSMFTALFVTKFALYCLFEAGLQDAKYYGVKKDTKVRPFLRYRKLCFAVSGVLILAGFAAMGINSASGGSILNYSMEFRGGTSTNVTFNEDMSLDRISSEVVPVVEKITGEAGTQTQKVAGTNEVIIKTRTLSVDEREELDQALVDTFGVDQEKITADSISGAISKEMKQDAVIAVVIATICMLLYIWFRFSNITFAASAVLALVHDVLVVVTFYAVFKWSVGSTFIACMLTIVGYSINATIVIFDRIRENMKLKKHTQTVEDVVNLSISQTLTRSINTSLTTFIMVFVLFLMGVSSIREFALPLMVGIVCGTYSSVCLTGSMWYLFNQKKEQKAAGERAAKTKKEK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGAACAAAAAAGGAAAGAGCCTCATAGGGCTGCTGCTCCTGCTTGTTGCTGTCGGTATTTTCGGTTATTTCGGATATTCGACAATGGGAGCAATCAAGCTGGGCCTGGATCTGGCCGGCGGAGTCAGCATTACCTACCAGGCAAAAGAGGCAAATCCGTCTTCTGAGGACATGGCGGATACGATTTATAAGCTGCAGCAGAGGGTGCAGAATTACAGCACCGAGGCGGAAGTTTACCAGGAAGGCAGCAACCGTATCAATGTAGATATTCCAGGCGTTTCCGATGCGAACGCGATCTTGCAGGAACTGGGCAAACCCGGCTCCCTTGTATTCCTTGATTCTGAGTTCAATCAGGTCCTGGACGGTAAACAGGTGAGCAGCGCCAAGGCCGGCATGGACGACAGCAGCGGAGTGAAGGAATATGTGGTTGCCTTGACCTTTAATGAAGAAGGTACAAAAGCGTTTGCCGATGCGACTACCAAAGGGGTCGGCAAGCCCATTTATATTGTATATGACGGCCAGCCAATTTCGGCTCCGAATGTAAAAGAACCGATTACAGGCGGACAGTGCCGTATCGACGGCATGGGCAGTTTTGAAGAGGCGGAGAACCTGGCTGCCACAATCCGAATCGGCTCCCTTTCATTGGAACTGGAAGAGCTGCGTTCTAACGTCGTAGGCGCAAAGCTTGGCCAGGAAGCGATTTCCACCAGCCTGAAGGCAGGCGCCATCGGTTTCGGCATCGTTGTTGTATTTATGATTTTTGCATACCTGATTCCGGGCCTTGCAGCATCTATCGCACTCTGCCTTTATGTGGGACTGATTCTTGTGCTGCTGGCAGCCTTTGAGGTAACATTAACTCTGCCGGGCGTTGCAGGTATTATCTTATCCATCGGTATGGCCGTGGATGCCAACGTTATTATCTTTACCCGTATCAAAGAAGAAATCGGAATGGGCAAGACAGTGAAATCTGCGATTAAGACAGGTTTTGCAAAGGCTCTGTCTGCCATCATCGACGGAAACGTTACAACGCTGATTGCGGCAGCCGTTCTTTTCTGGAGAGGCTCCGGTACGGTAAAAGGTTTTGCGTCCACACTGGCGATTGGTATCATCCTTTCCATGTTTACGGCTCTGTTCGTAACGAAATTTGCTCTCTACTGTCTGTTTGAGGCAGGTTTGCAGGATGCCAAATACTATGGCGTTAAGAAGGATACAAAGGTAAGGCCGTTCCTGAGATACAGAAAGCTGTGCTTCGCGGTTTCGGGTGTTTTGATTCTTGCCGGATTTGCGGCGATGGGAATTAACAGCGCTTCCGGCGGCTCAATTTTGAACTATAGTATGGAGTTCAGAGGCGGTACATCGACAAACGTAACGTTTAATGAGGATATGTCACTTGACCGGATATCTTCGGAGGTAGTGCCTGTTGTGGAGAAGATAACAGGGGAAGCGGGAACTCAGACACAGAAGGTAGCCGGAACCAATGAGGTAATCATTAAGACCAGGACTCTGAGCGTGGACGAGAGAGAAGAGCTGGATCAGGCTCTGGTTGATACCTTTGGCGTTGATCAGGAAAAGATCACGGCGGACAGTATCTCCGGTGCAATCAGCAAGGAGATGAAACAGGATGCGGTGATTGCCGTAGTGATTGCTACAATCTGTATGCTGCTTTATATCTGGTTCCGGTTCAGCAATATTACGTTTGCGGCAAGTGCGGTTCTGGCGCTGGTGCATGACGTACTCGTTGTCGTGACGTTCTACGCCGTCTTTAAATGGTCCGTGGGTTCCACGTTTATCGCATGTATGCTGACGATTGTCGGTTATTCCATCAATGCCACCATTGTTATATTTGACCGTATCCGTGAGAATATGAAGCTGAAAAAGCATACACAGACGGTGGAGGATGTTGTGAATTTAAGTATCAGCCAGACGCTGACGAGAAGTATCAATACCTCCCTGACAACATTTATCATGGTATTTGTTCTCTTCCTGATGGGAGTATCTTCCATCCGCGAGTTTGCACTTCCTCTGATGGTGGGTATTGTCTGCGGTACTTATTCTTCCGTATGCCTGACCGGCTCCATGTGGTACCTTTTCAATCAGAAAAAAGAACAGAAGGCGGCCGGAGAGCGGGCGGCAAAGACAAAGAAAGAGAAATAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 8146,
                        "end": 9543,
                        "strand": -1,
                        "locus_tag": "KGBDKNAJ_01091",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01091</span></strong><br>\n \n  GTP 3&#39;,8-cyclase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01091</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">moaA_1</span><br>\n \n Location: 8,146 - 9,543,\n (total: 1398 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIHQYINNGFYIVLDVNSGSVHSVDPLLYDAIKLLSGRLADMKEPAPVPRKTEEEVAELLKEKYSADEIQEAFSDIQELIDREELFTADIYKDYVMDFKKRQTVVKALCLHIAHDCNLACRYCFAEEGEYHGRRALMSYEVGKKALDFLIANSGARRNLEVDFFGGEPLMNWEVVKQLVEYGRSQEELHNKKFRFTLTTNGVLLNDEIMEFSNREMSNVVLSLDGRQDVNDRMRPFRNGRGSYDLIVPKFQKFAKERGDRDYFIRGTFTRNNLDFADDVLHFADLGFEKMSVEPVVASPEEPYAIREEDLPQIMEEYDRLAEEYIKRHKEGRGFTFFHFMLDLNQGPCVAKRLSGCGSGTEYLAVTPWGDLYPCHQFVGNEEFLLGNVDEGVTKTEICNEFKLCNVYAKDKCRDCFARFYCSGGCAANSFNFHGSITDAYDIGCEMQKKRIECAIMIKAALAEEE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIHQYINNGFYIVLDVNSGSVHSVDPLLYDAIKLLSGRLADMKEPAPVPRKTEEEVAELLKEKYSADEIQEAFSDIQELIDREELFTADIYKDYVMDFKKRQTVVKALCLHIAHDCNLACRYCFAEEGEYHGRRALMSYEVGKKALDFLIANSGARRNLEVDFFGGEPLMNWEVVKQLVEYGRSQEELHNKKFRFTLTTNGVLLNDEIMEFSNREMSNVVLSLDGRQDVNDRMRPFRNGRGSYDLIVPKFQKFAKERGDRDYFIRGTFTRNNLDFADDVLHFADLGFEKMSVEPVVASPEEPYAIREEDLPQIMEEYDRLAEEYIKRHKEGRGFTFFHFMLDLNQGPCVAKRLSGCGSGTEYLAVTPWGDLYPCHQFVGNEEFLLGNVDEGVTKTEICNEFKLCNVYAKDKCRDCFARFYCSGGCAANSFNFHGSITDAYDIGCEMQKKRIECAIMIKAALAEEE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGATTCATCAATATATAAATAACGGTTTTTATATCGTTTTAGACGTTAACAGCGGTTCTGTCCATTCGGTGGATCCGCTCCTTTATGATGCAATTAAGCTTCTCTCGGGCAGGCTTGCCGATATGAAAGAGCCTGCACCCGTACCGCGAAAGACCGAGGAGGAAGTGGCGGAGCTCCTGAAGGAGAAATACAGTGCGGATGAGATTCAGGAAGCTTTTTCCGACATACAGGAATTAATTGACAGGGAGGAGCTTTTTACCGCCGATATTTACAAAGACTACGTGATGGATTTTAAAAAGAGGCAGACTGTTGTAAAAGCGCTCTGTCTGCACATTGCCCATGACTGTAATCTGGCCTGCCGTTATTGTTTTGCGGAAGAGGGGGAGTACCACGGACGCAGGGCGCTGATGAGCTATGAGGTCGGTAAAAAAGCGCTGGATTTTCTGATCGCAAATTCGGGCGCCCGAAGAAATCTGGAAGTGGATTTTTTCGGCGGAGAGCCGCTTATGAACTGGGAAGTGGTAAAGCAGCTTGTGGAATACGGACGTTCCCAGGAAGAGCTTCATAATAAGAAGTTCCGTTTTACGCTGACAACCAACGGCGTACTTTTAAACGACGAGATTATGGAATTTAGCAACAGGGAGATGAGCAACGTAGTTTTAAGCCTTGACGGCAGACAGGACGTCAATGACCGGATGCGTCCGTTCCGGAACGGCAGGGGAAGCTATGACCTGATAGTGCCGAAGTTCCAGAAATTTGCCAAAGAACGCGGTGACAGGGATTACTTTATCCGGGGGACCTTTACGAGAAATAACCTGGACTTTGCAGACGATGTGCTCCATTTTGCCGATCTTGGATTTGAAAAGATGTCGGTGGAGCCTGTGGTGGCCTCTCCGGAGGAACCCTATGCCATCCGGGAAGAAGACCTTCCGCAGATCATGGAGGAGTACGACAGGCTGGCTGAGGAATATATAAAGCGCCACAAAGAGGGAAGGGGCTTTACCTTTTTCCATTTTATGCTGGACTTGAACCAGGGGCCGTGCGTTGCGAAGCGGTTATCCGGCTGCGGTTCAGGAACCGAATACCTGGCTGTAACGCCATGGGGAGATCTCTACCCCTGTCATCAGTTTGTGGGAAATGAAGAATTTCTTCTCGGCAATGTGGACGAGGGTGTGACAAAGACGGAGATTTGTAATGAATTCAAGCTCTGTAATGTCTACGCAAAGGATAAATGCAGGGATTGTTTTGCGAGATTTTACTGCAGCGGCGGCTGTGCGGCCAATTCTTTTAATTTCCATGGCTCTATTACAGATGCTTATGATATCGGATGTGAAATGCAGAAAAAGCGGATCGAGTGTGCAATTATGATTAAAGCTGCTCTGGCTGAGGAAGAATAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 9697,
                        "end": 9843,
                        "strand": -1,
                        "locus_tag": "KGBDKNAJ_01092",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01092</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01092</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,697 - 9,843,\n (total: 147 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR03973<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SCIFF<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKHVKTLNTNTLKNSMKKGGCGECQTSCQSACKTSCTVGNQSCENQNR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKHVKTLNTNTLKNSMKKGGCGECQTSCQSACKTSCTVGNQSCENQNR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACACGTTAAAACATTAAACACAAACACATTAAAAAACAGCATGAAGAAGGGCGGCTGCGGCGAGTGCCAGACATCCTGCCAGTCTGCATGTAAGACATCTTGTACAGTAGGAAACCAGAGCTGCGAGAATCAGAACCGATAA\">Copy to clipboard</span><br>\n</div>"
                    }
                ],
                "clusters": [
                    {
                        "start": 8145,
                        "end": 9843,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 0,
                        "neighbouring_end": 9965,
                        "product": "ranthipeptide",
                        "height": 2,
                        "kind": "protocluster",
                        "prefix": ""
                    }
                ],
                "ttaCodons": [],
                "type": "ranthipeptide",
                "products": [
                    "ranthipeptide"
                ],
                "anchor": "r97c1"
            }
        ]
    },
    {
        "length": 27242,
        "seq_id": "C14940.00105",
        "regions": []
    },
    {
        "length": 20345,
        "seq_id": "C14940.00106",
        "regions": []
    },
    {
        "length": 5262,
        "seq_id": "C14940.00107",
        "regions": []
    },
    {
        "length": 12323,
        "seq_id": "C14940.00108",
        "regions": []
    },
    {
        "length": 36791,
        "seq_id": "C14940.00109",
        "regions": []
    },
    {
        "length": 8680,
        "seq_id": "C14940.00110",
        "regions": []
    },
    {
        "length": 8312,
        "seq_id": "C14940.00111",
        "regions": []
    },
    {
        "length": 23428,
        "seq_id": "C14940.00113",
        "regions": []
    },
    {
        "length": 1299,
        "seq_id": "C14940.00114",
        "regions": []
    },
    {
        "length": 10667,
        "seq_id": "C14940.00115",
        "regions": []
    },
    {
        "length": 9458,
        "seq_id": "C14940.00116",
        "regions": []
    },
    {
        "length": 8385,
        "seq_id": "C14940.00117",
        "regions": []
    },
    {
        "length": 16812,
        "seq_id": "C14940.00118",
        "regions": []
    },
    {
        "length": 27596,
        "seq_id": "C14940.00119",
        "regions": []
    },
    {
        "length": 19437,
        "seq_id": "C14940.00120",
        "regions": []
    },
    {
        "length": 40342,
        "seq_id": "C14940.00121",
        "regions": []
    },
    {
        "length": 18255,
        "seq_id": "C14940.00122",
        "regions": []
    },
    {
        "length": 45990,
        "seq_id": "C14940.00123",
        "regions": []
    },
    {
        "length": 9382,
        "seq_id": "C14940.00124",
        "regions": []
    },
    {
        "length": 10626,
        "seq_id": "C14940.00125",
        "regions": []
    },
    {
        "length": 27131,
        "seq_id": "C14940.00126",
        "regions": []
    },
    {
        "length": 8275,
        "seq_id": "C14940.00127",
        "regions": []
    },
    {
        "length": 11669,
        "seq_id": "C14940.00128",
        "regions": []
    },
    {
        "length": 1202,
        "seq_id": "C14940.00129",
        "regions": []
    },
    {
        "length": 1322,
        "seq_id": "C14940.00130",
        "regions": []
    },
    {
        "length": 2507,
        "seq_id": "C14940.00131",
        "regions": []
    },
    {
        "length": 11465,
        "seq_id": "C14940.00132",
        "regions": []
    },
    {
        "length": 3072,
        "seq_id": "C14940.00133",
        "regions": []
    },
    {
        "length": 19306,
        "seq_id": "C14940.00134",
        "regions": []
    },
    {
        "length": 55308,
        "seq_id": "C14940.00135",
        "regions": []
    },
    {
        "length": 8074,
        "seq_id": "C14940.00136",
        "regions": []
    },
    {
        "length": 37893,
        "seq_id": "C14940.00137",
        "regions": []
    },
    {
        "length": 1695,
        "seq_id": "C14940.00138",
        "regions": []
    },
    {
        "length": 7208,
        "seq_id": "C14940.00139",
        "regions": []
    },
    {
        "length": 16535,
        "seq_id": "C14940.00140",
        "regions": []
    },
    {
        "length": 12594,
        "seq_id": "C14940.00141",
        "regions": []
    },
    {
        "length": 24586,
        "seq_id": "C14940.00142",
        "regions": []
    },
    {
        "length": 5463,
        "seq_id": "C14940.00143",
        "regions": []
    },
    {
        "length": 21024,
        "seq_id": "C14940.00144",
        "regions": []
    },
    {
        "length": 2051,
        "seq_id": "C14940.00145",
        "regions": []
    },
    {
        "length": 22839,
        "seq_id": "C14940.00146",
        "regions": []
    },
    {
        "length": 5107,
        "seq_id": "C14940.00147",
        "regions": []
    },
    {
        "length": 10889,
        "seq_id": "C14940.00148",
        "regions": []
    },
    {
        "length": 4522,
        "seq_id": "C14940.00149",
        "regions": []
    },
    {
        "length": 27943,
        "seq_id": "C14940.00150",
        "regions": []
    },
    {
        "length": 11652,
        "seq_id": "C14940.00152",
        "regions": []
    },
    {
        "length": 6333,
        "seq_id": "C14940.00153",
        "regions": []
    },
    {
        "length": 2553,
        "seq_id": "C14940.00154",
        "regions": []
    },
    {
        "length": 43048,
        "seq_id": "C14940.00155",
        "regions": []
    },
    {
        "length": 9852,
        "seq_id": "C14940.00156",
        "regions": []
    },
    {
        "length": 14714,
        "seq_id": "C14940.00157",
        "regions": []
    },
    {
        "length": 2341,
        "seq_id": "C14940.00158",
        "regions": []
    },
    {
        "length": 44555,
        "seq_id": "C14940.00159",
        "regions": []
    },
    {
        "length": 9249,
        "seq_id": "C14940.00160",
        "regions": []
    },
    {
        "length": 28033,
        "seq_id": "C14940.00161",
        "regions": []
    },
    {
        "length": 35720,
        "seq_id": "C14940.00162",
        "regions": []
    },
    {
        "length": 26370,
        "seq_id": "C14940.00163",
        "regions": []
    },
    {
        "length": 3359,
        "seq_id": "C14940.00164",
        "regions": []
    },
    {
        "length": 6113,
        "seq_id": "C14940.00165",
        "regions": []
    },
    {
        "length": 17144,
        "seq_id": "C14940.00166",
        "regions": []
    },
    {
        "length": 2455,
        "seq_id": "C14940.00167",
        "regions": []
    },
    {
        "length": 17643,
        "seq_id": "C14940.00168",
        "regions": []
    },
    {
        "length": 4844,
        "seq_id": "C14940.00169",
        "regions": []
    },
    {
        "length": 4074,
        "seq_id": "C14940.00170",
        "regions": []
    },
    {
        "length": 3593,
        "seq_id": "C14940.00171",
        "regions": []
    },
    {
        "length": 15176,
        "seq_id": "C14940.00172",
        "regions": []
    },
    {
        "length": 10073,
        "seq_id": "C14940.00173",
        "regions": []
    },
    {
        "length": 12458,
        "seq_id": "C14940.00174",
        "regions": []
    },
    {
        "length": 8042,
        "seq_id": "C14940.00175",
        "regions": []
    },
    {
        "length": 6387,
        "seq_id": "C14940.00176",
        "regions": []
    },
    {
        "length": 9108,
        "seq_id": "C14940.00177",
        "regions": []
    },
    {
        "length": 12224,
        "seq_id": "C14940.00178",
        "regions": []
    },
    {
        "length": 8981,
        "seq_id": "C14940.00179",
        "regions": []
    },
    {
        "length": 18575,
        "seq_id": "C14940.00180",
        "regions": []
    },
    {
        "length": 8561,
        "seq_id": "C14940.00181",
        "regions": []
    },
    {
        "length": 8244,
        "seq_id": "C14940.00182",
        "regions": []
    },
    {
        "length": 13908,
        "seq_id": "C14940.00183",
        "regions": []
    },
    {
        "length": 2869,
        "seq_id": "C14940.00184",
        "regions": []
    },
    {
        "length": 10455,
        "seq_id": "C14940.00185",
        "regions": []
    },
    {
        "length": 14535,
        "seq_id": "C14940.00186",
        "regions": []
    },
    {
        "length": 32049,
        "seq_id": "C14940.00187",
        "regions": []
    },
    {
        "length": 17561,
        "seq_id": "C14940.00188",
        "regions": []
    },
    {
        "length": 12130,
        "seq_id": "C14940.00189",
        "regions": []
    },
    {
        "length": 15719,
        "seq_id": "C14940.00190",
        "regions": []
    },
    {
        "length": 48675,
        "seq_id": "C14940.00192",
        "regions": []
    },
    {
        "length": 27763,
        "seq_id": "C14940.00193",
        "regions": []
    },
    {
        "length": 5550,
        "seq_id": "C14940.00194",
        "regions": []
    },
    {
        "length": 18505,
        "seq_id": "C14940.00195",
        "regions": []
    },
    {
        "length": 3166,
        "seq_id": "C14940.00196",
        "regions": []
    },
    {
        "length": 8634,
        "seq_id": "C14940.00197",
        "regions": []
    },
    {
        "length": 7101,
        "seq_id": "C14940.00198",
        "regions": []
    },
    {
        "length": 20678,
        "seq_id": "C14940.00199",
        "regions": []
    },
    {
        "length": 10857,
        "seq_id": "C14940.00200",
        "regions": []
    },
    {
        "length": 7963,
        "seq_id": "C14940.00201",
        "regions": []
    },
    {
        "length": 16293,
        "seq_id": "C14940.00202",
        "regions": []
    },
    {
        "length": 2323,
        "seq_id": "C14940.00203",
        "regions": []
    },
    {
        "length": 11927,
        "seq_id": "C14940.00205",
        "regions": []
    },
    {
        "length": 17281,
        "seq_id": "C14940.00206",
        "regions": []
    },
    {
        "length": 1345,
        "seq_id": "C14940.00207",
        "regions": []
    },
    {
        "length": 4438,
        "seq_id": "C14940.00208",
        "regions": []
    },
    {
        "length": 1614,
        "seq_id": "C14940.00209",
        "regions": []
    },
    {
        "length": 6349,
        "seq_id": "C14940.00211",
        "regions": []
    },
    {
        "length": 15981,
        "seq_id": "C14940.00212",
        "regions": []
    },
    {
        "length": 40840,
        "seq_id": "C14940.00213",
        "regions": []
    },
    {
        "length": 1070,
        "seq_id": "C14940.00217",
        "regions": []
    },
    {
        "length": 10975,
        "seq_id": "C14940.00218",
        "regions": []
    },
    {
        "length": 53548,
        "seq_id": "C14940.00219",
        "regions": []
    },
    {
        "length": 18291,
        "seq_id": "C14940.00220",
        "regions": []
    },
    {
        "length": 1055,
        "seq_id": "C14940.00221",
        "regions": []
    },
    {
        "length": 5122,
        "seq_id": "C14940.00223",
        "regions": []
    },
    {
        "length": 12619,
        "seq_id": "C14940.00224",
        "regions": []
    },
    {
        "length": 42445,
        "seq_id": "C14940.00225",
        "regions": []
    },
    {
        "length": 30142,
        "seq_id": "C14940.00226",
        "regions": []
    },
    {
        "length": 2109,
        "seq_id": "C14940.00227",
        "regions": []
    },
    {
        "length": 8967,
        "seq_id": "C14940.00228",
        "regions": []
    },
    {
        "length": 11139,
        "seq_id": "C14940.00229",
        "regions": []
    },
    {
        "length": 7391,
        "seq_id": "C14940.00230",
        "regions": []
    },
    {
        "length": 39372,
        "seq_id": "C14940.00231",
        "regions": []
    },
    {
        "length": 8220,
        "seq_id": "C14940.00232",
        "regions": []
    },
    {
        "length": 1383,
        "seq_id": "C14940.00233",
        "regions": []
    },
    {
        "length": 3183,
        "seq_id": "C14940.00234",
        "regions": []
    },
    {
        "length": 18196,
        "seq_id": "C14940.00235",
        "regions": []
    },
    {
        "length": 2151,
        "seq_id": "C14940.00236",
        "regions": []
    },
    {
        "length": 16719,
        "seq_id": "C14940.00237",
        "regions": []
    },
    {
        "length": 29135,
        "seq_id": "C14940.00239",
        "regions": []
    },
    {
        "length": 20903,
        "seq_id": "C14940.00240",
        "regions": []
    },
    {
        "length": 6458,
        "seq_id": "C14940.00241",
        "regions": []
    },
    {
        "length": 2860,
        "seq_id": "C14940.00242",
        "regions": []
    },
    {
        "length": 2362,
        "seq_id": "C14940.00244",
        "regions": []
    },
    {
        "length": 6351,
        "seq_id": "C14940.00245",
        "regions": []
    },
    {
        "length": 24743,
        "seq_id": "C14940.00246",
        "regions": []
    },
    {
        "length": 13854,
        "seq_id": "C14940.00247",
        "regions": []
    },
    {
        "length": 12254,
        "seq_id": "C14940.00249",
        "regions": []
    },
    {
        "length": 6593,
        "seq_id": "C14940.00250",
        "regions": []
    },
    {
        "length": 23733,
        "seq_id": "C14940.00254",
        "regions": []
    },
    {
        "length": 10350,
        "seq_id": "C14940.00255",
        "regions": []
    },
    {
        "length": 10619,
        "seq_id": "C14940.00256",
        "regions": []
    },
    {
        "length": 1997,
        "seq_id": "C14940.00257",
        "regions": []
    },
    {
        "length": 29860,
        "seq_id": "C14940.00258",
        "regions": []
    },
    {
        "length": 4732,
        "seq_id": "C14940.00259",
        "regions": []
    },
    {
        "length": 4044,
        "seq_id": "C14940.00260",
        "regions": []
    },
    {
        "length": 24278,
        "seq_id": "C14940.00261",
        "regions": []
    },
    {
        "length": 79327,
        "seq_id": "C14940.00262",
        "regions": []
    },
    {
        "length": 1310,
        "seq_id": "C14940.00263",
        "regions": []
    },
    {
        "length": 22100,
        "seq_id": "C14940.00264",
        "regions": []
    },
    {
        "length": 19646,
        "seq_id": "C14940.00265",
        "regions": []
    },
    {
        "length": 1166,
        "seq_id": "C14940.00267",
        "regions": []
    },
    {
        "length": 4886,
        "seq_id": "C14940.00268",
        "regions": []
    },
    {
        "length": 34556,
        "seq_id": "C14940.00269",
        "regions": []
    },
    {
        "length": 1580,
        "seq_id": "C14940.00270",
        "regions": []
    },
    {
        "length": 12845,
        "seq_id": "C14940.00271",
        "regions": []
    },
    {
        "length": 37885,
        "seq_id": "C14940.00272",
        "regions": []
    },
    {
        "length": 3645,
        "seq_id": "C14940.00273",
        "regions": []
    },
    {
        "length": 50453,
        "seq_id": "C14940.00275",
        "regions": []
    },
    {
        "length": 14638,
        "seq_id": "C14940.00277",
        "regions": []
    },
    {
        "length": 22259,
        "seq_id": "C14940.00278",
        "regions": []
    },
    {
        "length": 2548,
        "seq_id": "C14940.00279",
        "regions": []
    },
    {
        "length": 8508,
        "seq_id": "C14940.00280",
        "regions": []
    },
    {
        "length": 10236,
        "seq_id": "C14940.00281",
        "regions": []
    },
    {
        "length": 47950,
        "seq_id": "C14940.00282",
        "regions": []
    },
    {
        "length": 1086,
        "seq_id": "C14940.00284",
        "regions": []
    },
    {
        "length": 8074,
        "seq_id": "C14940.00285",
        "regions": []
    },
    {
        "length": 8098,
        "seq_id": "C14940.00286",
        "regions": []
    },
    {
        "length": 12111,
        "seq_id": "C14940.00287",
        "regions": []
    },
    {
        "length": 4395,
        "seq_id": "C14940.00288",
        "regions": []
    },
    {
        "length": 10741,
        "seq_id": "C14940.00289",
        "regions": []
    },
    {
        "length": 11214,
        "seq_id": "C14940.00290",
        "regions": []
    },
    {
        "length": 3172,
        "seq_id": "C14940.00291",
        "regions": []
    },
    {
        "length": 17922,
        "seq_id": "C14940.00292",
        "regions": []
    },
    {
        "length": 16558,
        "seq_id": "C14940.00293",
        "regions": []
    },
    {
        "length": 12528,
        "seq_id": "C14940.00294",
        "regions": []
    },
    {
        "length": 19746,
        "seq_id": "C14940.00295",
        "regions": []
    },
    {
        "length": 8330,
        "seq_id": "C14940.00296",
        "regions": []
    },
    {
        "length": 15551,
        "seq_id": "C14940.00297",
        "regions": []
    },
    {
        "length": 13965,
        "seq_id": "C14940.00298",
        "regions": []
    },
    {
        "length": 15903,
        "seq_id": "C14940.00299",
        "regions": []
    },
    {
        "length": 9989,
        "seq_id": "C14940.00300",
        "regions": []
    },
    {
        "length": 9461,
        "seq_id": "C14940.00301",
        "regions": []
    },
    {
        "length": 1868,
        "seq_id": "C14940.00302",
        "regions": []
    },
    {
        "length": 5511,
        "seq_id": "C14940.00303",
        "regions": []
    },
    {
        "length": 64383,
        "seq_id": "C14940.00304",
        "regions": []
    },
    {
        "length": 3231,
        "seq_id": "C14940.00305",
        "regions": []
    },
    {
        "length": 7972,
        "seq_id": "C14940.00306",
        "regions": []
    },
    {
        "length": 61709,
        "seq_id": "C14940.00307",
        "regions": []
    },
    {
        "length": 46482,
        "seq_id": "C14940.00308",
        "regions": []
    },
    {
        "length": 46943,
        "seq_id": "C14940.00309",
        "regions": []
    },
    {
        "length": 2560,
        "seq_id": "C14940.00310",
        "regions": []
    },
    {
        "length": 55300,
        "seq_id": "C14940.00311",
        "regions": []
    },
    {
        "length": 7655,
        "seq_id": "C14940.00313",
        "regions": []
    },
    {
        "length": 7899,
        "seq_id": "C14940.00314",
        "regions": []
    },
    {
        "length": 25372,
        "seq_id": "C14940.00316",
        "regions": []
    },
    {
        "length": 47387,
        "seq_id": "C14940.00317",
        "regions": []
    },
    {
        "length": 2665,
        "seq_id": "C14940.00318",
        "regions": []
    },
    {
        "length": 20488,
        "seq_id": "C14940.00319",
        "regions": []
    },
    {
        "length": 12848,
        "seq_id": "C14940.00320",
        "regions": []
    },
    {
        "length": 11965,
        "seq_id": "C14940.00321",
        "regions": []
    },
    {
        "length": 29692,
        "seq_id": "C14940.00322",
        "regions": []
    },
    {
        "length": 8320,
        "seq_id": "C14940.00323",
        "regions": []
    },
    {
        "length": 12425,
        "seq_id": "C14940.00324",
        "regions": []
    },
    {
        "length": 25296,
        "seq_id": "C14940.00325",
        "regions": []
    },
    {
        "length": 5384,
        "seq_id": "C14940.00326",
        "regions": []
    },
    {
        "length": 21820,
        "seq_id": "C14940.00327",
        "regions": []
    },
    {
        "length": 3652,
        "seq_id": "C14940.00328",
        "regions": []
    },
    {
        "length": 7794,
        "seq_id": "C14940.00329",
        "regions": []
    },
    {
        "length": 9345,
        "seq_id": "C14940.00330",
        "regions": []
    },
    {
        "length": 61992,
        "seq_id": "C14940.00331",
        "regions": []
    },
    {
        "length": 17589,
        "seq_id": "C14940.00332",
        "regions": []
    },
    {
        "length": 5461,
        "seq_id": "C14940.00333",
        "regions": []
    },
    {
        "length": 1293,
        "seq_id": "C14940.00334",
        "regions": []
    },
    {
        "length": 23027,
        "seq_id": "C14940.00335",
        "regions": []
    },
    {
        "length": 21021,
        "seq_id": "C14940.00336",
        "regions": []
    },
    {
        "length": 2982,
        "seq_id": "C14940.00337",
        "regions": []
    },
    {
        "length": 14058,
        "seq_id": "C14940.00338",
        "regions": []
    },
    {
        "length": 8643,
        "seq_id": "C14940.00339",
        "regions": []
    },
    {
        "length": 18096,
        "seq_id": "C14940.00340",
        "regions": []
    },
    {
        "length": 26499,
        "seq_id": "C14940.00341",
        "regions": []
    },
    {
        "length": 13218,
        "seq_id": "C14940.00342",
        "regions": []
    },
    {
        "length": 23896,
        "seq_id": "C14940.00343",
        "regions": []
    },
    {
        "length": 7383,
        "seq_id": "C14940.00344",
        "regions": []
    },
    {
        "length": 18667,
        "seq_id": "C14940.00345",
        "regions": []
    },
    {
        "length": 7546,
        "seq_id": "C14940.00346",
        "regions": []
    },
    {
        "length": 28494,
        "seq_id": "C14940.00347",
        "regions": []
    },
    {
        "length": 2398,
        "seq_id": "C14940.00348",
        "regions": []
    },
    {
        "length": 3704,
        "seq_id": "C14940.00349",
        "regions": []
    },
    {
        "length": 37515,
        "seq_id": "C14940.00350",
        "regions": []
    },
    {
        "length": 17912,
        "seq_id": "C14940.00351",
        "regions": []
    },
    {
        "length": 38543,
        "seq_id": "C14940.00352",
        "regions": []
    }
];
var all_regions = {
    "order": [
        "r97c1"
    ],
    "r97c1": {
        "start": 1,
        "end": 9965,
        "idx": 1,
        "orfs": [
            {
                "start": 310,
                "end": 900,
                "strand": -1,
                "locus_tag": "KGBDKNAJ_01082",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01082</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01082</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 310 - 900,\n (total: 591 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKKHWYDYLWIWSIIYFTLGFFNILFAWLGMIDFLVPVFIAVFGRNKWFCNNLCGRGQLFALLGGKYKCSRNRPTPRFLVSPWFRYGFLAFFMAMFGNMVFQTWLVAAGASGLREALKLFWTFKVPWGWTYTAGMVPDWVAQYSFGFYSLMLTSLLLGLIMMVLYKPRSWCTFCPMGTMTQGICKLGSRGETQDS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKKHWYDYLWIWSIIYFTLGFFNILFAWLGMIDFLVPVFIAVFGRNKWFCNNLCGRGQLFALLGGKYKCSRNRPTPRFLVSPWFRYGFLAFFMAMFGNMVFQTWLVAAGASGLREALKLFWTFKVPWGWTYTAGMVPDWVAQYSFGFYSLMLTSLLLGLIMMVLYKPRSWCTFCPMGTMTQGICKLGSRGETQDS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAAGAAACACTGGTATGACTATCTCTGGATATGGTCCATCATTTATTTTACACTGGGCTTCTTTAATATTTTATTTGCATGGCTTGGAATGATCGATTTTCTTGTGCCTGTTTTTATCGCTGTTTTCGGGAGAAATAAGTGGTTTTGCAACAATCTCTGCGGCCGCGGCCAATTGTTTGCGCTGCTGGGGGGAAAATATAAATGTTCCAGGAACAGGCCGACGCCCCGGTTTCTCGTATCGCCCTGGTTCCGTTACGGTTTTCTGGCCTTTTTCATGGCTATGTTCGGAAATATGGTGTTTCAGACCTGGCTTGTGGCGGCGGGGGCTTCGGGACTCAGGGAGGCGCTCAAACTGTTCTGGACCTTTAAAGTTCCATGGGGCTGGACTTACACCGCAGGAATGGTGCCGGACTGGGTGGCCCAGTACAGCTTCGGGTTCTACAGCCTGATGCTGACATCACTCTTACTTGGCCTGATTATGATGGTTCTCTATAAACCGAGAAGCTGGTGTACTTTCTGTCCGATGGGAACGATGACCCAGGGGATTTGCAAGCTGGGGAGCAGAGGGGAGACGCAGGACAGTTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 897,
                "end": 1109,
                "strand": -1,
                "locus_tag": "KGBDKNAJ_01083",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01083</span></strong><br>\n \n  NAD(P)H-quinone oxidoreductase subunit I, chloroplastic<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01083</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ndhI_1</span><br>\n \n Location: 897 - 1,109,\n (total: 213 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSVKTKRSVSVNLKRCVACGACCKVCPREAIAVSGGCYAAADLEKCVGCGLCEKLCPAGALSILIREAQL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSVKTKRSVSVNLKRCVACGACCKVCPREAIAVSGGCYAAADLEKCVGCGLCEKLCPAGALSILIREAQL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCTGTTAAAACAAAACGAAGTGTATCGGTGAACCTAAAACGATGCGTCGCGTGCGGAGCATGCTGTAAGGTCTGCCCCAGGGAGGCGATCGCGGTATCAGGAGGCTGCTATGCGGCTGCGGATTTGGAGAAGTGCGTCGGCTGCGGTCTGTGTGAAAAGCTGTGCCCGGCCGGTGCGCTCTCGATTCTTATCAGGGAGGCACAGCTATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1356,
                "end": 2225,
                "strand": 1,
                "locus_tag": "KGBDKNAJ_01084",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01084</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01084</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,356 - 2,225,\n (total: 870 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1148:hypothetical protein (Score: 68.3; E-value: 1.8e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSFSENLQYLRKKQNLTQEQFAEQMEVSRQAVSKWESGQSYPEMEKLLQICEQFGCSMDSLIKGDVTEAAKEDSTGYNRHMNRYSIMVSSAVALIIFSVAIIASLDGIVSEAVTSIILFVLIGIAVYILIIAGISHQYYRRRYPDIDNFYTEEQHANFNRIFAIAIASGVSLIVFSLCLNIWLEYTVIPYSEQISGGVFLLCTAVAVGIFTFFGMQKDKYDIGKYNQENRPEAPGKKHLASKLCGVIMLLATALFLFLGLSFDMFRSAAVIYPVAGIFCGIVCLLLSDK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSFSENLQYLRKKQNLTQEQFAEQMEVSRQAVSKWESGQSYPEMEKLLQICEQFGCSMDSLIKGDVTEAAKEDSTGYNRHMNRYSIMVSSAVALIIFSVAIIASLDGIVSEAVTSIILFVLIGIAVYILIIAGISHQYYRRRYPDIDNFYTEEQHANFNRIFAIAIASGVSLIVFSLCLNIWLEYTVIPYSEQISGGVFLLCTAVAVGIFTFFGMQKDKYDIGKYNQENRPEAPGKKHLASKLCGVIMLLATALFLFLGLSFDMFRSAAVIYPVAGIFCGIVCLLLSDK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTTTTTCAGAGAATTTACAATACTTAAGAAAAAAACAAAATTTGACACAGGAGCAGTTTGCCGAACAGATGGAGGTATCGAGACAGGCCGTCTCCAAATGGGAATCAGGCCAGTCTTACCCGGAGATGGAAAAACTGCTTCAGATATGCGAGCAGTTCGGATGTTCCATGGACAGCCTCATCAAAGGCGATGTGACAGAAGCGGCAAAAGAAGATTCGACAGGCTATAACCGCCATATGAACCGCTATTCCATCATGGTTTCCTCTGCCGTTGCCCTGATCATTTTTTCGGTCGCAATCATCGCCTCGCTGGACGGAATCGTAAGCGAAGCCGTTACAAGCATTATCCTGTTCGTATTGATCGGAATTGCCGTATATATCCTGATAATAGCCGGCATCAGCCATCAGTACTACCGCAGGCGTTATCCCGATATCGATAATTTCTACACGGAAGAACAGCATGCCAATTTCAACCGTATTTTTGCAATTGCCATAGCTTCCGGGGTCAGTCTCATTGTTTTTTCTCTCTGCCTGAACATCTGGCTTGAGTACACCGTTATCCCTTATTCTGAGCAGATAAGCGGAGGCGTTTTTCTTCTCTGTACCGCCGTGGCCGTCGGTATTTTCACTTTCTTTGGCATGCAGAAGGACAAATACGACATCGGCAAATATAACCAGGAAAACCGTCCGGAGGCTCCCGGCAAAAAGCACCTGGCGAGCAAGCTGTGCGGCGTCATCATGCTCCTGGCGACAGCTCTCTTCCTGTTCCTCGGCCTTTCATTTGATATGTTCCGGTCCGCAGCCGTCATTTATCCGGTCGCAGGAATCTTCTGCGGTATCGTCTGCCTGCTGCTGAGCGATAAATAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 2336,
                "end": 2761,
                "strand": -1,
                "locus_tag": "KGBDKNAJ_01085",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01085</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01085</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,336 - 2,761,\n (total: 426 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MEKRYADAAIFYAAAAMVFGVFYREFTKFNGFTGKTNLSVMHTHYFLLGMFFFLILMLLEKNFRFSGGEKIGIILTVYHIGLNVTALGFLLRGLTQVWGTELSRGMDASISGLSGVGHIMLGISMILLLLKIRKKTVLEKK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MEKRYADAAIFYAAAAMVFGVFYREFTKFNGFTGKTNLSVMHTHYFLLGMFFFLILMLLEKNFRFSGGEKIGIILTVYHIGLNVTALGFLLRGLTQVWGTELSRGMDASISGLSGVGHIMLGISMILLLLKIRKKTVLEKK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAAAAACGTTATGCGGATGCAGCCATATTCTATGCAGCGGCTGCCATGGTATTCGGTGTGTTTTACAGGGAGTTTACAAAATTTAACGGTTTTACCGGAAAAACTAATTTATCTGTCATGCATACACATTATTTTCTGTTGGGAATGTTTTTCTTTCTCATACTGATGCTGCTTGAAAAGAATTTCCGGTTTTCCGGCGGGGAGAAGATTGGAATAATTCTGACAGTCTATCACATAGGTTTGAATGTCACCGCCCTCGGTTTTCTTTTAAGGGGTCTGACACAGGTATGGGGTACCGAACTCAGCAGGGGGATGGATGCTTCCATATCGGGCCTTTCCGGTGTGGGCCATATTATGCTGGGAATCAGCATGATTCTGTTGTTGCTGAAGATCAGAAAAAAGACGGTCTTAGAAAAAAAGTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 2777,
                "end": 3454,
                "strand": -1,
                "locus_tag": "KGBDKNAJ_01086",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01086</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01086</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,777 - 3,454,\n (total: 678 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAQAIAETVFDILYLGFALITGLTMLTKGKSRIVKMAGWMTALLGAGDSFHLVPRSYALWTTGMEANAAALGIGKFITSVTMTVFYLILYYIWRERYQIRERKTLTGVMWFLACLRIGFCLLPQNEWLSYHQPLSYGILRNIPFAIMGIIIIVIFAAEAGKKADPVFWFMPLAAGLSFGFYLPVVLFSGAVPAVGMLMIPKTLAYVWMIWMARRLYKEETIIRHT&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAQAIAETVFDILYLGFALITGLTMLTKGKSRIVKMAGWMTALLGAGDSFHLVPRSYALWTTGMEANAAALGIGKFITSVTMTVFYLILYYIWRERYQIRERKTLTGVMWFLACLRIGFCLLPQNEWLSYHQPLSYGILRNIPFAIMGIIIIVIFAAEAGKKADPVFWFMPLAAGLSFGFYLPVVLFSGAVPAVGMLMIPKTLAYVWMIWMARRLYKEETIIRHT\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCACAGGCGATTGCTGAAACAGTTTTTGACATTTTATATCTTGGTTTTGCCCTGATAACAGGACTGACTATGCTGACAAAAGGAAAGAGCCGGATCGTAAAAATGGCAGGATGGATGACGGCGCTGCTGGGGGCAGGGGATTCCTTTCATCTGGTACCGCGTTCCTACGCACTTTGGACAACAGGGATGGAAGCAAATGCAGCCGCATTGGGGATTGGGAAATTTATTACGTCTGTCACGATGACGGTTTTTTATCTGATTTTATATTATATCTGGCGTGAGCGTTACCAGATTCGGGAACGTAAGACACTTACCGGTGTAATGTGGTTTTTAGCATGCCTGAGGATTGGATTTTGTCTTCTGCCTCAGAACGAGTGGCTGTCCTATCACCAGCCTCTGTCTTATGGGATACTGCGAAATATCCCATTTGCGATAATGGGAATTATCATTATCGTAATCTTTGCCGCAGAGGCCGGGAAAAAAGCGGATCCGGTGTTCTGGTTTATGCCTTTGGCGGCGGGACTTTCCTTTGGTTTCTACCTGCCCGTCGTATTGTTCAGCGGCGCAGTACCGGCCGTGGGCATGCTGATGATTCCAAAGACACTGGCTTACGTCTGGATGATTTGGATGGCGAGACGGCTTTACAAAGAAGAAACAATAATCAGGCATACATAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 3474,
                "end": 4073,
                "strand": -1,
                "locus_tag": "KGBDKNAJ_01087",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01087</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01087</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,474 - 4,073,\n (total: 600 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MYSIYEHVHLNEKGDDTVRKKDDSLRGALIDYARELAEKEGPEAVNIRSLAGKAGIATGTVYNYFSCKDEILLALTEEYWRKTLADMRAAVTAPSFCGQLEEIFTFLRERIDSSAGMLMHSLGNVRETGQERMESMQEVLEAAMVYRMEQDPGIRSDIWDETFTKRDYARFIMANMMLLLREHPYDFRFFLEIVKRTVY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MYSIYEHVHLNEKGDDTVRKKDDSLRGALIDYARELAEKEGPEAVNIRSLAGKAGIATGTVYNYFSCKDEILLALTEEYWRKTLADMRAAVTAPSFCGQLEEIFTFLRERIDSSAGMLMHSLGNVRETGQERMESMQEVLEAAMVYRMEQDPGIRSDIWDETFTKRDYARFIMANMMLLLREHPYDFRFFLEIVKRTVY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTATAGTATATATGAACATGTTCATTTAAATGAAAAAGGGGATGATACGGTGCGGAAAAAAGACGACAGCCTGAGGGGGGCACTGATTGACTATGCCCGGGAACTGGCGGAGAAAGAGGGGCCTGAGGCAGTCAATATACGCTCTCTGGCCGGGAAAGCCGGGATTGCGACGGGCACGGTATATAATTATTTTTCATGTAAAGACGAAATCCTCCTGGCTCTCACGGAAGAATACTGGAGAAAGACCTTGGCCGATATGAGGGCGGCAGTCACGGCCCCCTCATTCTGCGGGCAGCTGGAGGAAATTTTTACTTTTTTACGGGAGCGTATCGACAGCTCCGCCGGAATGCTGATGCACAGCCTCGGGAATGTCAGGGAGACAGGGCAGGAGAGAATGGAATCCATGCAGGAGGTTCTGGAAGCCGCAATGGTGTATCGGATGGAGCAGGATCCGGGCATACGCAGTGATATCTGGGACGAAACATTTACAAAGAGAGATTATGCCCGTTTTATTATGGCGAATATGATGCTGCTGCTCAGGGAGCATCCATATGATTTCCGGTTTTTTCTGGAAATAGTCAAACGGACCGTTTATTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 4418,
                "end": 4690,
                "strand": -1,
                "locus_tag": "KGBDKNAJ_01088",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01088</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01088</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,418 - 4,690,\n (total: 273 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGTAGWVLYFVFIIGLMYFIAIRPQQKEKKKMQELMAGVAVGDSVLTSSGFYGVIIDMTDDTVIVEFGSNKNCRIPMRKDAIVQVEKPEL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGTAGWVLYFVFIIGLMYFIAIRPQQKEKKKMQELMAGVAVGDSVLTSSGFYGVIIDMTDDTVIVEFGSNKNCRIPMRKDAIVQVEKPEL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGCACAGCGGGCTGGGTACTATATTTTGTCTTTATCATAGGACTTATGTACTTTATTGCGATCAGACCACAGCAGAAGGAAAAGAAAAAAATGCAGGAGCTGATGGCAGGTGTCGCAGTAGGCGACAGCGTTTTAACATCCAGTGGATTTTACGGCGTAATCATCGACATGACAGATGATACGGTTATCGTAGAATTCGGCAGCAACAAGAACTGCCGTATTCCTATGCGCAAGGATGCAATTGTTCAGGTTGAGAAACCGGAACTGTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 4780,
                "end": 5922,
                "strand": -1,
                "locus_tag": "KGBDKNAJ_01089",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01089</span></strong><br>\n \n  Queuine tRNA-ribosyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01089</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">tgt</span><br>\n \n Location: 4,780 - 5,922,\n (total: 1143 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MEYKILYKDGRAKRAEMKTVHGTVQTPVFMNVGTVGAIKGAVSTDDLKEIGTQVELSNTYHLHVRTGDKLIKQFGGLHKFMNWDRPILTDSGGFQVFSLSGLRKIKEEGVYFNSHIDGRKIFMGPEESMQIQSNLGSTIAMAFDECPSSVASREYVQASVDRTTRWLERCREEMKRLNAQPDTVNREQLLFGINQGAIYEDIRIGHAKTISKMELDGYAVGGLAVGETHEEMYRILDAVVPHLPEDKPTYLMGVGTPANILEAVDRGVDFFDCVYPTRNGRHSHVYTNHGKMNLLNAKYELDKKPIEEGCGCPACRSYSRAYIRHLFKAKEMLGMRLCVLHNLYFYNKMMEEIRDAIEHHRYAEYKTAKLAGMMAGEEAK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MEYKILYKDGRAKRAEMKTVHGTVQTPVFMNVGTVGAIKGAVSTDDLKEIGTQVELSNTYHLHVRTGDKLIKQFGGLHKFMNWDRPILTDSGGFQVFSLSGLRKIKEEGVYFNSHIDGRKIFMGPEESMQIQSNLGSTIAMAFDECPSSVASREYVQASVDRTTRWLERCREEMKRLNAQPDTVNREQLLFGINQGAIYEDIRIGHAKTISKMELDGYAVGGLAVGETHEEMYRILDAVVPHLPEDKPTYLMGVGTPANILEAVDRGVDFFDCVYPTRNGRHSHVYTNHGKMNLLNAKYELDKKPIEEGCGCPACRSYSRAYIRHLFKAKEMLGMRLCVLHNLYFYNKMMEEIRDAIEHHRYAEYKTAKLAGMMAGEEAK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAGTATAAGATTCTTTACAAAGACGGACGCGCGAAACGGGCAGAGATGAAAACCGTCCATGGAACTGTCCAGACACCTGTTTTCATGAATGTGGGAACTGTGGGGGCGATAAAGGGAGCCGTATCTACCGACGATCTGAAGGAAATCGGAACACAGGTAGAGTTGTCCAACACCTACCATCTGCACGTGAGAACCGGTGACAAGCTGATTAAGCAGTTTGGCGGACTTCATAAATTCATGAACTGGGACAGGCCGATTCTGACGGATTCCGGCGGTTTTCAGGTATTTTCCCTGTCGGGACTTCGAAAGATAAAGGAAGAGGGCGTTTATTTTAACTCTCATATCGACGGCAGGAAGATATTCATGGGTCCGGAGGAGAGCATGCAGATCCAGTCCAATCTGGGCTCCACAATCGCAATGGCATTTGATGAATGTCCGTCCAGCGTGGCTTCAAGGGAATACGTCCAGGCCTCGGTAGACAGAACCACAAGATGGCTTGAACGCTGCCGGGAAGAGATGAAACGCCTGAATGCTCAGCCGGATACGGTGAACCGTGAGCAGCTCCTCTTTGGAATCAATCAGGGAGCAATTTACGAGGATATCCGCATCGGGCATGCAAAGACAATCAGCAAGATGGAGCTGGACGGCTATGCTGTGGGCGGCCTGGCCGTGGGTGAAACCCATGAGGAGATGTACCGTATCCTCGATGCGGTGGTTCCCCATCTTCCGGAGGATAAGCCTACGTACCTGATGGGGGTCGGAACGCCTGCCAATATTTTAGAGGCGGTGGACCGCGGCGTTGATTTCTTTGACTGCGTGTATCCGACCAGAAACGGCCGGCACAGCCATGTCTATACAAACCATGGCAAGATGAATCTGCTGAATGCAAAATATGAACTGGATAAAAAGCCGATTGAAGAGGGCTGCGGCTGCCCGGCATGCCGTTCCTACAGCAGGGCCTATATAAGACATCTGTTTAAGGCAAAAGAAATGCTCGGGATGCGATTATGTGTATTGCATAATTTATATTTTTATAATAAAATGATGGAAGAGATTCGCGACGCAATCGAACATCACCGTTATGCCGAATATAAGACTGCAAAGCTTGCCGGCATGATGGCCGGAGAGGAAGCAAAATAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 5926,
                "end": 8082,
                "strand": -1,
                "locus_tag": "KGBDKNAJ_01090",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01090</span></strong><br>\n \n  Protein translocase subunit SecDF<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01090</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">secDF_1</span><br>\n \n Location: 5,926 - 8,082,\n (total: 2157 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKNKKGKSLIGLLLLLVAVGIFGYFGYSTMGAIKLGLDLAGGVSITYQAKEANPSSEDMADTIYKLQQRVQNYSTEAEVYQEGSNRINVDIPGVSDANAILQELGKPGSLVFLDSEFNQVLDGKQVSSAKAGMDDSSGVKEYVVALTFNEEGTKAFADATTKGVGKPIYIVYDGQPISAPNVKEPITGGQCRIDGMGSFEEAENLAATIRIGSLSLELEELRSNVVGAKLGQEAISTSLKAGAIGFGIVVVFMIFAYLIPGLAASIALCLYVGLILVLLAAFEVTLTLPGVAGIILSIGMAVDANVIIFTRIKEEIGMGKTVKSAIKTGFAKALSAIIDGNVTTLIAAAVLFWRGSGTVKGFASTLAIGIILSMFTALFVTKFALYCLFEAGLQDAKYYGVKKDTKVRPFLRYRKLCFAVSGVLILAGFAAMGINSASGGSILNYSMEFRGGTSTNVTFNEDMSLDRISSEVVPVVEKITGEAGTQTQKVAGTNEVIIKTRTLSVDEREELDQALVDTFGVDQEKITADSISGAISKEMKQDAVIAVVIATICMLLYIWFRFSNITFAASAVLALVHDVLVVVTFYAVFKWSVGSTFIACMLTIVGYSINATIVIFDRIRENMKLKKHTQTVEDVVNLSISQTLTRSINTSLTTFIMVFVLFLMGVSSIREFALPLMVGIVCGTYSSVCLTGSMWYLFNQKKEQKAAGERAAKTKKEK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKNKKGKSLIGLLLLLVAVGIFGYFGYSTMGAIKLGLDLAGGVSITYQAKEANPSSEDMADTIYKLQQRVQNYSTEAEVYQEGSNRINVDIPGVSDANAILQELGKPGSLVFLDSEFNQVLDGKQVSSAKAGMDDSSGVKEYVVALTFNEEGTKAFADATTKGVGKPIYIVYDGQPISAPNVKEPITGGQCRIDGMGSFEEAENLAATIRIGSLSLELEELRSNVVGAKLGQEAISTSLKAGAIGFGIVVVFMIFAYLIPGLAASIALCLYVGLILVLLAAFEVTLTLPGVAGIILSIGMAVDANVIIFTRIKEEIGMGKTVKSAIKTGFAKALSAIIDGNVTTLIAAAVLFWRGSGTVKGFASTLAIGIILSMFTALFVTKFALYCLFEAGLQDAKYYGVKKDTKVRPFLRYRKLCFAVSGVLILAGFAAMGINSASGGSILNYSMEFRGGTSTNVTFNEDMSLDRISSEVVPVVEKITGEAGTQTQKVAGTNEVIIKTRTLSVDEREELDQALVDTFGVDQEKITADSISGAISKEMKQDAVIAVVIATICMLLYIWFRFSNITFAASAVLALVHDVLVVVTFYAVFKWSVGSTFIACMLTIVGYSINATIVIFDRIRENMKLKKHTQTVEDVVNLSISQTLTRSINTSLTTFIMVFVLFLMGVSSIREFALPLMVGIVCGTYSSVCLTGSMWYLFNQKKEQKAAGERAAKTKKEK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGAACAAAAAAGGAAAGAGCCTCATAGGGCTGCTGCTCCTGCTTGTTGCTGTCGGTATTTTCGGTTATTTCGGATATTCGACAATGGGAGCAATCAAGCTGGGCCTGGATCTGGCCGGCGGAGTCAGCATTACCTACCAGGCAAAAGAGGCAAATCCGTCTTCTGAGGACATGGCGGATACGATTTATAAGCTGCAGCAGAGGGTGCAGAATTACAGCACCGAGGCGGAAGTTTACCAGGAAGGCAGCAACCGTATCAATGTAGATATTCCAGGCGTTTCCGATGCGAACGCGATCTTGCAGGAACTGGGCAAACCCGGCTCCCTTGTATTCCTTGATTCTGAGTTCAATCAGGTCCTGGACGGTAAACAGGTGAGCAGCGCCAAGGCCGGCATGGACGACAGCAGCGGAGTGAAGGAATATGTGGTTGCCTTGACCTTTAATGAAGAAGGTACAAAAGCGTTTGCCGATGCGACTACCAAAGGGGTCGGCAAGCCCATTTATATTGTATATGACGGCCAGCCAATTTCGGCTCCGAATGTAAAAGAACCGATTACAGGCGGACAGTGCCGTATCGACGGCATGGGCAGTTTTGAAGAGGCGGAGAACCTGGCTGCCACAATCCGAATCGGCTCCCTTTCATTGGAACTGGAAGAGCTGCGTTCTAACGTCGTAGGCGCAAAGCTTGGCCAGGAAGCGATTTCCACCAGCCTGAAGGCAGGCGCCATCGGTTTCGGCATCGTTGTTGTATTTATGATTTTTGCATACCTGATTCCGGGCCTTGCAGCATCTATCGCACTCTGCCTTTATGTGGGACTGATTCTTGTGCTGCTGGCAGCCTTTGAGGTAACATTAACTCTGCCGGGCGTTGCAGGTATTATCTTATCCATCGGTATGGCCGTGGATGCCAACGTTATTATCTTTACCCGTATCAAAGAAGAAATCGGAATGGGCAAGACAGTGAAATCTGCGATTAAGACAGGTTTTGCAAAGGCTCTGTCTGCCATCATCGACGGAAACGTTACAACGCTGATTGCGGCAGCCGTTCTTTTCTGGAGAGGCTCCGGTACGGTAAAAGGTTTTGCGTCCACACTGGCGATTGGTATCATCCTTTCCATGTTTACGGCTCTGTTCGTAACGAAATTTGCTCTCTACTGTCTGTTTGAGGCAGGTTTGCAGGATGCCAAATACTATGGCGTTAAGAAGGATACAAAGGTAAGGCCGTTCCTGAGATACAGAAAGCTGTGCTTCGCGGTTTCGGGTGTTTTGATTCTTGCCGGATTTGCGGCGATGGGAATTAACAGCGCTTCCGGCGGCTCAATTTTGAACTATAGTATGGAGTTCAGAGGCGGTACATCGACAAACGTAACGTTTAATGAGGATATGTCACTTGACCGGATATCTTCGGAGGTAGTGCCTGTTGTGGAGAAGATAACAGGGGAAGCGGGAACTCAGACACAGAAGGTAGCCGGAACCAATGAGGTAATCATTAAGACCAGGACTCTGAGCGTGGACGAGAGAGAAGAGCTGGATCAGGCTCTGGTTGATACCTTTGGCGTTGATCAGGAAAAGATCACGGCGGACAGTATCTCCGGTGCAATCAGCAAGGAGATGAAACAGGATGCGGTGATTGCCGTAGTGATTGCTACAATCTGTATGCTGCTTTATATCTGGTTCCGGTTCAGCAATATTACGTTTGCGGCAAGTGCGGTTCTGGCGCTGGTGCATGACGTACTCGTTGTCGTGACGTTCTACGCCGTCTTTAAATGGTCCGTGGGTTCCACGTTTATCGCATGTATGCTGACGATTGTCGGTTATTCCATCAATGCCACCATTGTTATATTTGACCGTATCCGTGAGAATATGAAGCTGAAAAAGCATACACAGACGGTGGAGGATGTTGTGAATTTAAGTATCAGCCAGACGCTGACGAGAAGTATCAATACCTCCCTGACAACATTTATCATGGTATTTGTTCTCTTCCTGATGGGAGTATCTTCCATCCGCGAGTTTGCACTTCCTCTGATGGTGGGTATTGTCTGCGGTACTTATTCTTCCGTATGCCTGACCGGCTCCATGTGGTACCTTTTCAATCAGAAAAAAGAACAGAAGGCGGCCGGAGAGCGGGCGGCAAAGACAAAGAAAGAGAAATAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 8146,
                "end": 9543,
                "strand": -1,
                "locus_tag": "KGBDKNAJ_01091",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01091</span></strong><br>\n \n  GTP 3&#39;,8-cyclase<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01091</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">moaA_1</span><br>\n \n Location: 8,146 - 9,543,\n (total: 1398 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIHQYINNGFYIVLDVNSGSVHSVDPLLYDAIKLLSGRLADMKEPAPVPRKTEEEVAELLKEKYSADEIQEAFSDIQELIDREELFTADIYKDYVMDFKKRQTVVKALCLHIAHDCNLACRYCFAEEGEYHGRRALMSYEVGKKALDFLIANSGARRNLEVDFFGGEPLMNWEVVKQLVEYGRSQEELHNKKFRFTLTTNGVLLNDEIMEFSNREMSNVVLSLDGRQDVNDRMRPFRNGRGSYDLIVPKFQKFAKERGDRDYFIRGTFTRNNLDFADDVLHFADLGFEKMSVEPVVASPEEPYAIREEDLPQIMEEYDRLAEEYIKRHKEGRGFTFFHFMLDLNQGPCVAKRLSGCGSGTEYLAVTPWGDLYPCHQFVGNEEFLLGNVDEGVTKTEICNEFKLCNVYAKDKCRDCFARFYCSGGCAANSFNFHGSITDAYDIGCEMQKKRIECAIMIKAALAEEE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIHQYINNGFYIVLDVNSGSVHSVDPLLYDAIKLLSGRLADMKEPAPVPRKTEEEVAELLKEKYSADEIQEAFSDIQELIDREELFTADIYKDYVMDFKKRQTVVKALCLHIAHDCNLACRYCFAEEGEYHGRRALMSYEVGKKALDFLIANSGARRNLEVDFFGGEPLMNWEVVKQLVEYGRSQEELHNKKFRFTLTTNGVLLNDEIMEFSNREMSNVVLSLDGRQDVNDRMRPFRNGRGSYDLIVPKFQKFAKERGDRDYFIRGTFTRNNLDFADDVLHFADLGFEKMSVEPVVASPEEPYAIREEDLPQIMEEYDRLAEEYIKRHKEGRGFTFFHFMLDLNQGPCVAKRLSGCGSGTEYLAVTPWGDLYPCHQFVGNEEFLLGNVDEGVTKTEICNEFKLCNVYAKDKCRDCFARFYCSGGCAANSFNFHGSITDAYDIGCEMQKKRIECAIMIKAALAEEE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGATTCATCAATATATAAATAACGGTTTTTATATCGTTTTAGACGTTAACAGCGGTTCTGTCCATTCGGTGGATCCGCTCCTTTATGATGCAATTAAGCTTCTCTCGGGCAGGCTTGCCGATATGAAAGAGCCTGCACCCGTACCGCGAAAGACCGAGGAGGAAGTGGCGGAGCTCCTGAAGGAGAAATACAGTGCGGATGAGATTCAGGAAGCTTTTTCCGACATACAGGAATTAATTGACAGGGAGGAGCTTTTTACCGCCGATATTTACAAAGACTACGTGATGGATTTTAAAAAGAGGCAGACTGTTGTAAAAGCGCTCTGTCTGCACATTGCCCATGACTGTAATCTGGCCTGCCGTTATTGTTTTGCGGAAGAGGGGGAGTACCACGGACGCAGGGCGCTGATGAGCTATGAGGTCGGTAAAAAAGCGCTGGATTTTCTGATCGCAAATTCGGGCGCCCGAAGAAATCTGGAAGTGGATTTTTTCGGCGGAGAGCCGCTTATGAACTGGGAAGTGGTAAAGCAGCTTGTGGAATACGGACGTTCCCAGGAAGAGCTTCATAATAAGAAGTTCCGTTTTACGCTGACAACCAACGGCGTACTTTTAAACGACGAGATTATGGAATTTAGCAACAGGGAGATGAGCAACGTAGTTTTAAGCCTTGACGGCAGACAGGACGTCAATGACCGGATGCGTCCGTTCCGGAACGGCAGGGGAAGCTATGACCTGATAGTGCCGAAGTTCCAGAAATTTGCCAAAGAACGCGGTGACAGGGATTACTTTATCCGGGGGACCTTTACGAGAAATAACCTGGACTTTGCAGACGATGTGCTCCATTTTGCCGATCTTGGATTTGAAAAGATGTCGGTGGAGCCTGTGGTGGCCTCTCCGGAGGAACCCTATGCCATCCGGGAAGAAGACCTTCCGCAGATCATGGAGGAGTACGACAGGCTGGCTGAGGAATATATAAAGCGCCACAAAGAGGGAAGGGGCTTTACCTTTTTCCATTTTATGCTGGACTTGAACCAGGGGCCGTGCGTTGCGAAGCGGTTATCCGGCTGCGGTTCAGGAACCGAATACCTGGCTGTAACGCCATGGGGAGATCTCTACCCCTGTCATCAGTTTGTGGGAAATGAAGAATTTCTTCTCGGCAATGTGGACGAGGGTGTGACAAAGACGGAGATTTGTAATGAATTCAAGCTCTGTAATGTCTACGCAAAGGATAAATGCAGGGATTGTTTTGCGAGATTTTACTGCAGCGGCGGCTGTGCGGCCAATTCTTTTAATTTCCATGGCTCTATTACAGATGCTTATGATATCGGATGTGAAATGCAGAAAAAGCGGATCGAGTGTGCAATTATGATTAAAGCTGCTCTGGCTGAGGAAGAATAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 9697,
                "end": 9843,
                "strand": -1,
                "locus_tag": "KGBDKNAJ_01092",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">KGBDKNAJ_01092</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">KGBDKNAJ_01092</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,697 - 9,843,\n (total: 147 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR03973<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SCIFF<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKHVKTLNTNTLKNSMKKGGCGECQTSCQSACKTSCTVGNQSCENQNR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=C14940.00104&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKHVKTLNTNTLKNSMKKGGCGECQTSCQSACKTSCTVGNQSCENQNR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACACGTTAAAACATTAAACACAAACACATTAAAAAACAGCATGAAGAAGGGCGGCTGCGGCGAGTGCCAGACATCCTGCCAGTCTGCATGTAAGACATCTTGTACAGTAGGAAACCAGAGCTGCGAGAATCAGAACCGATAA\">Copy to clipboard</span><br>\n</div>"
            }
        ],
        "clusters": [
            {
                "start": 8145,
                "end": 9843,
                "tool": "rule-based-clusters",
                "neighbouring_start": 0,
                "neighbouring_end": 9965,
                "product": "ranthipeptide",
                "height": 2,
                "kind": "protocluster",
                "prefix": ""
            }
        ],
        "ttaCodons": [],
        "type": "ranthipeptide",
        "products": [
            "ranthipeptide"
        ],
        "anchor": "r97c1"
    }
};
var details_data = {
    "nrpspks": {},
    "pfam": {}
};
var resultsData = {};
