var recordData = [
    {
        "length": 4076,
        "seq_id": "NZ_KE992784.1",
        "regions": []
    },
    {
        "length": 12103,
        "seq_id": "NZ_KE992785.1",
        "regions": []
    },
    {
        "length": 2973,
        "seq_id": "NZ_KE992786.1",
        "regions": []
    },
    {
        "length": 31675,
        "seq_id": "NZ_KE992787.1",
        "regions": []
    },
    {
        "length": 13854,
        "seq_id": "NZ_KE992788.1",
        "regions": []
    },
    {
        "length": 8502,
        "seq_id": "NZ_KE992789.1",
        "regions": []
    },
    {
        "length": 44949,
        "seq_id": "NZ_KE992790.1",
        "regions": []
    },
    {
        "length": 1103,
        "seq_id": "NZ_KE992792.1",
        "regions": []
    },
    {
        "length": 18947,
        "seq_id": "NZ_KE992793.1",
        "regions": []
    },
    {
        "length": 8961,
        "seq_id": "NZ_KE992794.1",
        "regions": []
    },
    {
        "length": 79730,
        "seq_id": "NZ_KE992795.1",
        "regions": []
    },
    {
        "length": 12779,
        "seq_id": "NZ_KE992796.1",
        "regions": []
    },
    {
        "length": 1116,
        "seq_id": "NZ_KE992797.1",
        "regions": []
    },
    {
        "length": 8876,
        "seq_id": "NZ_KE992798.1",
        "regions": []
    },
    {
        "length": 104630,
        "seq_id": "NZ_KE992799.1",
        "regions": []
    },
    {
        "length": 54470,
        "seq_id": "NZ_KE992800.1",
        "regions": []
    },
    {
        "length": 1310,
        "seq_id": "NZ_KE992801.1",
        "regions": []
    },
    {
        "length": 41846,
        "seq_id": "NZ_KE992802.1",
        "regions": []
    },
    {
        "length": 19227,
        "seq_id": "NZ_KE992804.1",
        "regions": []
    },
    {
        "length": 1166,
        "seq_id": "NZ_KE992805.1",
        "regions": []
    },
    {
        "length": 2027,
        "seq_id": "NZ_KE992806.1",
        "regions": []
    },
    {
        "length": 41222,
        "seq_id": "NZ_KE992807.1",
        "regions": []
    },
    {
        "length": 1491,
        "seq_id": "NZ_KE992808.1",
        "regions": []
    },
    {
        "length": 12845,
        "seq_id": "NZ_KE992809.1",
        "regions": []
    },
    {
        "length": 39135,
        "seq_id": "NZ_KE992810.1",
        "regions": []
    },
    {
        "length": 3645,
        "seq_id": "NZ_KE992811.1",
        "regions": []
    },
    {
        "length": 2825,
        "seq_id": "NZ_KE992813.1",
        "regions": []
    },
    {
        "length": 14827,
        "seq_id": "NZ_KE992814.1",
        "regions": []
    },
    {
        "length": 10067,
        "seq_id": "NZ_KE992816.1",
        "regions": []
    },
    {
        "length": 54917,
        "seq_id": "NZ_KE992817.1",
        "regions": []
    },
    {
        "length": 19013,
        "seq_id": "NZ_KE992819.1",
        "regions": []
    },
    {
        "length": 15046,
        "seq_id": "NZ_KE992820.1",
        "regions": []
    },
    {
        "length": 10173,
        "seq_id": "NZ_KE992821.1",
        "regions": []
    },
    {
        "length": 5115,
        "seq_id": "NZ_KE992822.1",
        "regions": []
    },
    {
        "length": 43851,
        "seq_id": "NZ_KE992823.1",
        "regions": []
    },
    {
        "length": 47950,
        "seq_id": "NZ_KE992824.1",
        "regions": []
    },
    {
        "length": 1926,
        "seq_id": "NZ_KE992825.1",
        "regions": []
    },
    {
        "length": 3189,
        "seq_id": "NZ_KE992826.1",
        "regions": []
    },
    {
        "length": 16272,
        "seq_id": "NZ_KE992827.1",
        "regions": []
    },
    {
        "length": 12111,
        "seq_id": "NZ_KE992828.1",
        "regions": []
    },
    {
        "length": 4395,
        "seq_id": "NZ_KE992829.1",
        "regions": []
    },
    {
        "length": 1047,
        "seq_id": "NZ_KE992830.1",
        "regions": []
    },
    {
        "length": 13422,
        "seq_id": "NZ_KE992831.1",
        "regions": []
    },
    {
        "length": 1614,
        "seq_id": "NZ_KE992832.1",
        "regions": []
    },
    {
        "length": 1629,
        "seq_id": "NZ_KE992833.1",
        "regions": []
    },
    {
        "length": 58823,
        "seq_id": "NZ_KE992834.1",
        "regions": []
    },
    {
        "length": 10741,
        "seq_id": "NZ_KE992835.1",
        "regions": []
    },
    {
        "length": 32508,
        "seq_id": "NZ_KE992836.1",
        "regions": []
    },
    {
        "length": 8646,
        "seq_id": "NZ_KE992837.1",
        "regions": []
    },
    {
        "length": 14180,
        "seq_id": "NZ_KE992839.1",
        "regions": []
    },
    {
        "length": 3337,
        "seq_id": "NZ_KE992840.1",
        "regions": []
    },
    {
        "length": 1070,
        "seq_id": "NZ_KE992841.1",
        "regions": []
    },
    {
        "length": 29186,
        "seq_id": "NZ_KE992842.1",
        "regions": []
    },
    {
        "length": 43827,
        "seq_id": "NZ_KE992843.1",
        "regions": []
    },
    {
        "length": 29968,
        "seq_id": "NZ_KE992844.1",
        "regions": []
    },
    {
        "length": 10779,
        "seq_id": "NZ_KE992845.1",
        "regions": []
    },
    {
        "length": 9989,
        "seq_id": "NZ_KE992846.1",
        "regions": []
    },
    {
        "length": 11429,
        "seq_id": "NZ_KE992847.1",
        "regions": []
    },
    {
        "length": 5916,
        "seq_id": "NZ_KE992848.1",
        "regions": []
    },
    {
        "length": 6547,
        "seq_id": "NZ_KE992849.1",
        "regions": []
    },
    {
        "length": 64383,
        "seq_id": "NZ_KE992850.1",
        "regions": []
    },
    {
        "length": 4323,
        "seq_id": "NZ_KE992851.1",
        "regions": []
    },
    {
        "length": 3167,
        "seq_id": "NZ_KE992852.1",
        "regions": []
    },
    {
        "length": 3625,
        "seq_id": "NZ_KE992853.1",
        "regions": []
    },
    {
        "length": 19967,
        "seq_id": "NZ_KE992854.1",
        "regions": []
    },
    {
        "length": 69781,
        "seq_id": "NZ_KE992855.1",
        "regions": []
    },
    {
        "length": 53733,
        "seq_id": "NZ_KE992856.1",
        "regions": []
    },
    {
        "length": 1856,
        "seq_id": "NZ_KE992857.1",
        "regions": []
    },
    {
        "length": 46793,
        "seq_id": "NZ_KE992858.1",
        "regions": []
    },
    {
        "length": 105003,
        "seq_id": "NZ_KE992859.1",
        "regions": []
    },
    {
        "length": 25724,
        "seq_id": "NZ_KE992861.1",
        "regions": []
    },
    {
        "length": 23490,
        "seq_id": "NZ_KE992862.1",
        "regions": []
    },
    {
        "length": 1665,
        "seq_id": "NZ_KE992863.1",
        "regions": []
    },
    {
        "length": 43735,
        "seq_id": "NZ_KE992864.1",
        "regions": []
    },
    {
        "length": 13439,
        "seq_id": "NZ_KE992865.1",
        "regions": []
    },
    {
        "length": 7981,
        "seq_id": "NZ_KE992867.1",
        "regions": []
    },
    {
        "length": 3207,
        "seq_id": "NZ_KE992868.1",
        "regions": []
    },
    {
        "length": 1598,
        "seq_id": "NZ_KE992869.1",
        "regions": []
    },
    {
        "length": 8500,
        "seq_id": "NZ_KE992870.1",
        "regions": []
    },
    {
        "length": 25696,
        "seq_id": "NZ_KE992871.1",
        "regions": []
    },
    {
        "length": 50152,
        "seq_id": "NZ_KE992872.1",
        "regions": []
    },
    {
        "length": 46252,
        "seq_id": "NZ_KE992873.1",
        "regions": []
    },
    {
        "length": 26235,
        "seq_id": "NZ_KE992874.1",
        "regions": []
    },
    {
        "length": 50959,
        "seq_id": "NZ_KE992875.1",
        "regions": []
    },
    {
        "length": 8918,
        "seq_id": "NZ_KE992876.1",
        "regions": []
    },
    {
        "length": 2745,
        "seq_id": "NZ_KE992877.1",
        "regions": []
    },
    {
        "length": 29982,
        "seq_id": "NZ_KE992878.1",
        "regions": []
    },
    {
        "length": 6437,
        "seq_id": "NZ_KE992879.1",
        "regions": []
    },
    {
        "length": 24510,
        "seq_id": "NZ_KE992880.1",
        "regions": []
    },
    {
        "length": 25296,
        "seq_id": "NZ_KE992881.1",
        "regions": []
    },
    {
        "length": 9453,
        "seq_id": "NZ_KE992882.1",
        "regions": []
    },
    {
        "length": 11418,
        "seq_id": "NZ_KE992883.1",
        "regions": []
    },
    {
        "length": 5384,
        "seq_id": "NZ_KE992884.1",
        "regions": []
    },
    {
        "length": 1129,
        "seq_id": "NZ_KE992885.1",
        "regions": []
    },
    {
        "length": 25903,
        "seq_id": "NZ_KE992887.1",
        "regions": []
    },
    {
        "length": 11064,
        "seq_id": "NZ_KE992888.1",
        "regions": []
    },
    {
        "length": 17581,
        "seq_id": "NZ_KE992889.1",
        "regions": []
    },
    {
        "length": 61992,
        "seq_id": "NZ_KE992890.1",
        "regions": []
    },
    {
        "length": 17936,
        "seq_id": "NZ_KE992891.1",
        "regions": []
    },
    {
        "length": 26952,
        "seq_id": "NZ_KE992892.1",
        "regions": []
    },
    {
        "length": 38483,
        "seq_id": "NZ_KE992894.1",
        "regions": []
    },
    {
        "length": 5461,
        "seq_id": "NZ_KE992895.1",
        "regions": []
    },
    {
        "length": 19440,
        "seq_id": "NZ_KE992896.1",
        "regions": []
    },
    {
        "length": 1293,
        "seq_id": "NZ_KE992897.1",
        "regions": []
    },
    {
        "length": 7466,
        "seq_id": "NZ_KE992898.1",
        "regions": []
    },
    {
        "length": 2756,
        "seq_id": "NZ_KE992899.1",
        "regions": []
    },
    {
        "length": 10590,
        "seq_id": "NZ_KE992900.1",
        "regions": []
    },
    {
        "length": 23027,
        "seq_id": "NZ_KE992901.1",
        "regions": []
    },
    {
        "length": 21496,
        "seq_id": "NZ_KE992902.1",
        "regions": []
    },
    {
        "length": 1116,
        "seq_id": "NZ_KE992903.1",
        "regions": []
    },
    {
        "length": 3046,
        "seq_id": "NZ_KE992904.1",
        "regions": []
    },
    {
        "length": 3790,
        "seq_id": "NZ_KE992905.1",
        "regions": []
    },
    {
        "length": 14714,
        "seq_id": "NZ_KE992906.1",
        "regions": []
    },
    {
        "length": 8643,
        "seq_id": "NZ_KE992907.1",
        "regions": []
    },
    {
        "length": 9965,
        "seq_id": "NZ_KE992908.1",
        "regions": [
            {
                "start": 1,
                "end": 9965,
                "idx": 1,
                "orfs": [
                    {
                        "start": 310,
                        "end": 900,
                        "strand": -1,
                        "locus_tag": "MLALJMBA_02066",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02066</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02066</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 310 - 900,\n (total: 591 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKKHWYDYLWIWSIIYFTLGFFNILFAWLGMIDFLVPVFIAVFGRNKWFCNNLCGRGQLFALLGGKYKCSRNRPTPRFLVSPWFRYGFLAFFMAMFGNMVFQTWLVAAGASGLREALKLFWTFKVPWGWTYTAGMVPDWVAQYSFGFYSLMLTSLLLGLIMMVLYKPRSWCTFCPMGTMTQGICKLGSRGETQDS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKKHWYDYLWIWSIIYFTLGFFNILFAWLGMIDFLVPVFIAVFGRNKWFCNNLCGRGQLFALLGGKYKCSRNRPTPRFLVSPWFRYGFLAFFMAMFGNMVFQTWLVAAGASGLREALKLFWTFKVPWGWTYTAGMVPDWVAQYSFGFYSLMLTSLLLGLIMMVLYKPRSWCTFCPMGTMTQGICKLGSRGETQDS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAAGAAACACTGGTATGACTATCTCTGGATATGGTCCATCATTTATTTTACACTGGGCTTCTTTAATATTTTATTTGCATGGCTTGGAATGATCGATTTTCTTGTGCCTGTTTTTATCGCTGTTTTCGGGAGAAATAAGTGGTTTTGCAACAATCTCTGCGGCCGCGGCCAATTGTTTGCGCTGCTGGGGGGAAAATATAAATGTTCCAGGAACAGGCCGACGCCCCGGTTTCTCGTATCGCCCTGGTTCCGTTACGGTTTTCTGGCCTTTTTCATGGCTATGTTCGGAAATATGGTGTTTCAGACCTGGCTTGTGGCGGCGGGGGCTTCGGGACTCAGGGAGGCGCTCAAACTGTTCTGGACCTTTAAAGTTCCATGGGGCTGGACTTACACCGCAGGAATGGTGCCGGACTGGGTGGCCCAGTACAGCTTCGGGTTCTACAGCCTGATGCTGACATCACTCTTACTTGGCCTGATTATGATGGTTCTCTATAAACCGAGAAGCTGGTGTACTTTCTGTCCGATGGGAACGATGACCCAGGGGATTTGCAAGCTGGGGAGCAGAGGGGAGACGCAGGACAGTTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 897,
                        "end": 1109,
                        "strand": -1,
                        "locus_tag": "MLALJMBA_02067",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02067</span></strong><br>\n \n  NAD(P)H-quinone oxidoreductase subunit I, chloroplastic<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02067</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ndhI_1</span><br>\n \n Location: 897 - 1,109,\n (total: 213 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSVKTKRSVSVNLKRCVACGACCKVCPREAIAVSGGCYAAADLEKCVGCGLCEKLCPAGALSILIREAQL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSVKTKRSVSVNLKRCVACGACCKVCPREAIAVSGGCYAAADLEKCVGCGLCEKLCPAGALSILIREAQL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCTGTTAAAACAAAACGAAGTGTATCGGTGAACCTAAAACGATGCGTCGCGTGCGGAGCATGCTGTAAGGTCTGCCCCAGGGAGGCGATCGCGGTATCAGGAGGCTGCTATGCGGCTGCGGATTTGGAGAAGTGCGTCGGCTGCGGTCTGTGTGAAAAGCTGTGCCCGGCCGGTGCGCTCTCGATTCTTATCAGGGAGGCACAGCTATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1356,
                        "end": 2225,
                        "strand": 1,
                        "locus_tag": "MLALJMBA_02068",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02068</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02068</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,356 - 2,225,\n (total: 870 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1148:hypothetical protein (Score: 68.3; E-value: 1.8e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSFSENLQYLRKKQNLTQEQFAEQMEVSRQAVSKWESGQSYPEMEKLLQICEQFGCSMDSLIKGDVTEAAKEDSTGYNRHMNRYSIMVSSAVALIIFSVAIIASLDGIVSEAVTSIILFVLIGIAVYILIIAGISHQYYRRRYPDIDNFYTEEQHANFNRIFAIAIASGVSLIVFSLCLNIWLEYTVIPYSEQISGGVFLLCTAVAVGIFTFFGMQKDKYDIGKYNQENRPEAPGKKHLASKLCGVIMLLATALFLFLGLSFDMFRSAAVIYPVAGIFCGIVCLLLSDK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSFSENLQYLRKKQNLTQEQFAEQMEVSRQAVSKWESGQSYPEMEKLLQICEQFGCSMDSLIKGDVTEAAKEDSTGYNRHMNRYSIMVSSAVALIIFSVAIIASLDGIVSEAVTSIILFVLIGIAVYILIIAGISHQYYRRRYPDIDNFYTEEQHANFNRIFAIAIASGVSLIVFSLCLNIWLEYTVIPYSEQISGGVFLLCTAVAVGIFTFFGMQKDKYDIGKYNQENRPEAPGKKHLASKLCGVIMLLATALFLFLGLSFDMFRSAAVIYPVAGIFCGIVCLLLSDK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTTTTTCAGAGAATTTACAATACTTAAGAAAAAAACAAAATTTGACACAGGAGCAGTTTGCCGAACAGATGGAGGTATCGAGACAGGCCGTCTCCAAATGGGAATCAGGCCAGTCTTACCCGGAGATGGAAAAACTGCTTCAGATATGCGAGCAGTTCGGATGTTCCATGGACAGCCTCATCAAAGGCGATGTGACAGAAGCGGCAAAAGAAGATTCGACAGGCTATAACCGCCATATGAACCGCTATTCCATCATGGTTTCCTCTGCCGTTGCCCTGATCATTTTTTCGGTCGCAATCATCGCCTCGCTGGACGGAATCGTAAGCGAAGCCGTTACAAGCATTATCCTGTTCGTATTGATCGGAATTGCCGTATATATCCTGATAATAGCCGGCATCAGCCATCAGTACTACCGCAGGCGTTATCCCGATATCGATAATTTCTACACGGAAGAACAGCATGCCAATTTCAACCGTATTTTTGCAATTGCCATAGCTTCCGGGGTCAGTCTCATTGTTTTTTCTCTCTGCCTGAACATCTGGCTTGAGTACACCGTTATCCCTTATTCTGAGCAGATAAGCGGAGGCGTTTTTCTTCTCTGTACCGCCGTGGCCGTCGGTATTTTCACTTTCTTTGGCATGCAGAAGGACAAATACGACATCGGCAAATATAACCAGGAAAACCGTCCGGAGGCTCCCGGCAAAAAGCACCTGGCGAGCAAGCTGTGCGGCGTCATCATGCTCCTGGCGACAGCTCTCTTCCTGTTCCTCGGCCTTTCATTTGATATGTTCCGGTCCGCAGCCGTCATTTATCCGGTCGCAGGAATCTTCTGCGGTATCGTCTGCCTGCTGCTGAGCGATAAATAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 2336,
                        "end": 2761,
                        "strand": -1,
                        "locus_tag": "MLALJMBA_02069",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02069</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02069</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,336 - 2,761,\n (total: 426 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MEKRYADAAIFYAAAAMVFGVFYREFTKFNGFTGKTNLSVMHTHYFLLGMFFFLILMLLEKNFRFSGGEKIGIILTVYHIGLNVTALGFLLRGLTQVWGTELSRGMDASISGLSGVGHIMLGISMILLLLKIRKKTVLEKK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MEKRYADAAIFYAAAAMVFGVFYREFTKFNGFTGKTNLSVMHTHYFLLGMFFFLILMLLEKNFRFSGGEKIGIILTVYHIGLNVTALGFLLRGLTQVWGTELSRGMDASISGLSGVGHIMLGISMILLLLKIRKKTVLEKK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAAAAACGTTATGCGGATGCAGCCATATTCTATGCAGCGGCTGCCATGGTATTCGGTGTGTTTTACAGGGAGTTTACAAAATTTAACGGTTTTACCGGAAAAACTAATTTATCTGTCATGCATACACATTATTTTCTGTTGGGAATGTTTTTCTTTCTCATACTGATGCTGCTTGAAAAGAATTTCCGGTTTTCCGGCGGGGAGAAGATTGGAATAATTCTGACAGTCTATCACATAGGTTTGAATGTCACCGCCCTCGGTTTTCTTTTAAGGGGTCTGACACAGGTATGGGGTACCGAACTCAGCAGGGGGATGGATGCTTCCATATCGGGCCTTTCCGGTGTGGGCCATATTATGCTGGGAATCAGCATGATTCTGTTGTTGCTGAAGATCAGAAAAAAGACGGTCTTAGAAAAAAAGTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 2777,
                        "end": 3454,
                        "strand": -1,
                        "locus_tag": "MLALJMBA_02070",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02070</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02070</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,777 - 3,454,\n (total: 678 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAQAIAETVFDILYLGFALITGLTMLTKGKSRIVKMAGWMTALLGAGDSFHLVPRSYALWTTGMEANAAALGIGKFITSVTMTVFYLILYYIWRERYQIRERKTLTGVMWFLACLRIGFCLLPQNEWLSYHQPLSYGILRNIPFAIMGIIIIVIFAAEAGKKADPVFWFMPLAAGLSFGFYLPVVLFSGAVPAVGMLMIPKTLAYVWMIWMARRLYKEETIIRHT&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAQAIAETVFDILYLGFALITGLTMLTKGKSRIVKMAGWMTALLGAGDSFHLVPRSYALWTTGMEANAAALGIGKFITSVTMTVFYLILYYIWRERYQIRERKTLTGVMWFLACLRIGFCLLPQNEWLSYHQPLSYGILRNIPFAIMGIIIIVIFAAEAGKKADPVFWFMPLAAGLSFGFYLPVVLFSGAVPAVGMLMIPKTLAYVWMIWMARRLYKEETIIRHT\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCACAGGCGATTGCTGAAACAGTTTTTGACATTTTATATCTTGGTTTTGCCCTGATAACAGGACTGACTATGCTGACAAAAGGAAAGAGCCGGATCGTAAAAATGGCAGGATGGATGACGGCGCTGCTGGGGGCAGGGGATTCCTTTCATCTGGTACCGCGTTCCTACGCACTTTGGACAACAGGGATGGAAGCAAATGCAGCCGCATTGGGGATTGGGAAATTTATTACGTCTGTCACGATGACGGTTTTTTATCTGATTTTATATTATATCTGGCGTGAGCGTTACCAGATTCGGGAACGTAAGACACTTACCGGTGTAATGTGGTTTTTAGCATGCCTGAGGATTGGATTTTGTCTTCTGCCTCAGAACGAGTGGCTGTCCTATCACCAGCCTCTGTCTTATGGGATACTGCGAAATATCCCATTTGCGATAATGGGAATTATCATTATCGTAATCTTTGCCGCAGAGGCCGGGAAAAAAGCGGATCCGGTGTTCTGGTTTATGCCTTTGGCGGCGGGACTTTCCTTTGGTTTCTACCTGCCCGTCGTATTGTTCAGCGGCGCAGTACCGGCCGTGGGCATGCTGATGATTCCAAAGACACTGGCTTACGTCTGGATGATTTGGATGGCGAGACGGCTTTACAAAGAAGAAACAATAATCAGGCATACATAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 3474,
                        "end": 4073,
                        "strand": -1,
                        "locus_tag": "MLALJMBA_02071",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02071</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02071</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,474 - 4,073,\n (total: 600 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MYSIYEHVHLNEKGDDTVRKKDDSLRGALIDYARELAEKEGPEAVNIRSLAGKAGIATGTVYNYFSCKDEILLALTEEYWRKTLADMRAAVTAPSFCGQLEEIFTFLRERIDSSAGMLMHSLGNVRETGQERMESMQEVLEAAMVYRMEQDPGIRSDIWDETFTKRDYARFIMANMMLLLREHPYDFRFFLEIVKRTVY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MYSIYEHVHLNEKGDDTVRKKDDSLRGALIDYARELAEKEGPEAVNIRSLAGKAGIATGTVYNYFSCKDEILLALTEEYWRKTLADMRAAVTAPSFCGQLEEIFTFLRERIDSSAGMLMHSLGNVRETGQERMESMQEVLEAAMVYRMEQDPGIRSDIWDETFTKRDYARFIMANMMLLLREHPYDFRFFLEIVKRTVY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTATAGTATATATGAACATGTTCATTTAAATGAAAAAGGGGATGATACGGTGCGGAAAAAAGACGACAGCCTGAGGGGGGCACTGATTGACTATGCCCGGGAACTGGCGGAGAAAGAGGGGCCTGAGGCAGTCAATATACGCTCTCTGGCCGGGAAAGCCGGGATTGCGACGGGCACGGTATATAATTATTTTTCATGTAAAGACGAAATCCTCCTGGCTCTCACGGAAGAATACTGGAGAAAGACCTTGGCCGATATGAGGGCGGCAGTCACGGCCCCCTCATTCTGCGGGCAGCTGGAGGAAATTTTTACTTTTTTACGGGAGCGTATCGACAGCTCCGCCGGAATGCTGATGCACAGCCTCGGGAATGTCAGGGAGACAGGGCAGGAGAGAATGGAATCCATGCAGGAGGTTCTGGAAGCCGCAATGGTGTATCGGATGGAGCAGGATCCGGGCATACGCAGTGATATCTGGGACGAAACATTTACAAAGAGAGATTATGCCCGTTTTATTATGGCGAATATGATGCTGCTGCTCAGGGAGCATCCATATGATTTCCGGTTTTTTCTGGAAATAGTCAAACGGACCGTTTATTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 4418,
                        "end": 4690,
                        "strand": -1,
                        "locus_tag": "MLALJMBA_02072",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02072</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02072</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,418 - 4,690,\n (total: 273 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGTAGWVLYFVFIIGLMYFIAIRPQQKEKKKMQELMAGVAVGDSVLTSSGFYGVIIDMTDDTVIVEFGSNKNCRIPMRKDAIVQVEKPEL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGTAGWVLYFVFIIGLMYFIAIRPQQKEKKKMQELMAGVAVGDSVLTSSGFYGVIIDMTDDTVIVEFGSNKNCRIPMRKDAIVQVEKPEL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGCACAGCGGGCTGGGTACTATATTTTGTCTTTATCATAGGACTTATGTACTTTATTGCGATCAGACCACAGCAGAAGGAAAAGAAAAAAATGCAGGAGCTGATGGCAGGTGTCGCAGTAGGCGACAGCGTTTTAACATCCAGTGGATTTTACGGCGTAATCATCGACATGACAGATGATACGGTTATCGTAGAATTCGGCAGCAACAAGAACTGCCGTATTCCTATGCGCAAGGATGCAATTGTTCAGGTTGAGAAACCGGAACTGTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 4780,
                        "end": 5922,
                        "strand": -1,
                        "locus_tag": "MLALJMBA_02073",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02073</span></strong><br>\n \n  Queuine tRNA-ribosyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02073</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">tgt</span><br>\n \n Location: 4,780 - 5,922,\n (total: 1143 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MEYKILYKDGRAKRAEMKTVHGTVQTPVFMNVGTVGAIKGAVSTDDLKEIGTQVELSNTYHLHVRTGDKLIKQFGGLHKFMNWDRPILTDSGGFQVFSLSGLRKIKEEGVYFNSHIDGRKIFMGPEESMQIQSNLGSTIAMAFDECPSSVASREYVQASVDRTTRWLERCREEMKRLNAQPDTVNREQLLFGINQGAIYEDIRIGHAKTISKMELDGYAVGGLAVGETHEEMYRILDAVVPHLPEDKPTYLMGVGTPANILEAVDRGVDFFDCVYPTRNGRHSHVYTNHGKMNLLNAKYELDKKPIEEGCGCPACRSYSRAYIRHLFKAKEMLGMRLCVLHNLYFYNKMMEEIRDAIEHHRYAEYKTAKLAGMMAGEEAK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MEYKILYKDGRAKRAEMKTVHGTVQTPVFMNVGTVGAIKGAVSTDDLKEIGTQVELSNTYHLHVRTGDKLIKQFGGLHKFMNWDRPILTDSGGFQVFSLSGLRKIKEEGVYFNSHIDGRKIFMGPEESMQIQSNLGSTIAMAFDECPSSVASREYVQASVDRTTRWLERCREEMKRLNAQPDTVNREQLLFGINQGAIYEDIRIGHAKTISKMELDGYAVGGLAVGETHEEMYRILDAVVPHLPEDKPTYLMGVGTPANILEAVDRGVDFFDCVYPTRNGRHSHVYTNHGKMNLLNAKYELDKKPIEEGCGCPACRSYSRAYIRHLFKAKEMLGMRLCVLHNLYFYNKMMEEIRDAIEHHRYAEYKTAKLAGMMAGEEAK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAGTATAAGATTCTTTACAAAGACGGACGCGCGAAACGGGCAGAGATGAAAACCGTCCATGGAACTGTCCAGACACCTGTTTTCATGAATGTGGGAACTGTGGGGGCGATAAAGGGAGCCGTATCTACCGACGATCTGAAGGAAATCGGAACACAGGTAGAGTTGTCCAACACCTACCATCTGCACGTGAGAACCGGTGACAAGCTGATTAAGCAGTTTGGCGGACTTCATAAATTCATGAACTGGGACAGGCCGATTCTGACGGATTCCGGCGGTTTTCAGGTATTTTCCCTGTCGGGACTTCGAAAGATAAAGGAAGAGGGCGTTTATTTTAACTCTCATATCGACGGCAGGAAGATATTCATGGGTCCGGAGGAGAGCATGCAGATCCAGTCCAATCTGGGCTCCACAATCGCAATGGCATTTGATGAATGTCCGTCCAGCGTGGCTTCAAGGGAATACGTCCAGGCCTCGGTAGACAGAACCACAAGATGGCTTGAACGCTGCCGGGAAGAGATGAAACGCCTGAATGCTCAGCCGGATACGGTGAACCGTGAGCAGCTCCTCTTTGGAATCAATCAGGGAGCAATTTACGAGGATATCCGCATCGGGCATGCAAAGACAATCAGCAAGATGGAGCTGGACGGCTATGCTGTGGGCGGCCTGGCCGTGGGTGAAACCCATGAGGAGATGTACCGTATCCTCGATGCGGTGGTTCCCCATCTTCCGGAGGATAAGCCTACGTACCTGATGGGGGTCGGAACGCCTGCCAATATTTTAGAGGCGGTGGACCGCGGCGTTGATTTCTTTGACTGCGTGTATCCGACCAGAAACGGCCGGCACAGCCATGTCTATACAAACCATGGCAAGATGAATCTGCTGAATGCAAAATATGAACTGGATAAAAAGCCGATTGAAGAGGGCTGCGGCTGCCCGGCATGCCGTTCCTACAGCAGGGCCTATATAAGACATCTGTTTAAGGCAAAAGAAATGCTCGGGATGCGATTATGTGTATTGCATAATTTATATTTTTATAATAAAATGATGGAAGAGATTCGCGACGCAATCGAACATCACCGTTATGCCGAATATAAGACTGCAAAGCTTGCCGGCATGATGGCCGGAGAGGAAGCAAAATAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 5926,
                        "end": 8082,
                        "strand": -1,
                        "locus_tag": "MLALJMBA_02074",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02074</span></strong><br>\n \n  Protein translocase subunit SecDF<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02074</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">secDF_2</span><br>\n \n Location: 5,926 - 8,082,\n (total: 2157 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKNKKGKSLIGLLLLLVAVGIFGYFGYSTMGAIKLGLDLAGGVSITYQAKEANPSSEDMADTIYKLQQRVQNYSTEAEVYQEGSNRINVDIPGVSDANAILQELGKPGSLVFLDSEFNQVLDGKQVSSAKAGMDDSSGVKEYVVALTFNEEGTKAFADATTKGVGKPIYIVYDGQPISAPNVKEPITGGQCRIDGMGSFEEAENLAATIRIGSLSLELEELRSNVVGAKLGQEAISTSLKAGAIGFGIVVVFMIFAYLIPGLAASIALCLYVGLILVLLAAFEVTLTLPGVAGIILSIGMAVDANVIIFTRIKEEIGMGKTVKSAIKTGFAKALSAIIDGNVTTLIAAAVLFWRGSGTVKGFASTLAIGIILSMFTALFVTKFALYCLFEAGLQDAKYYGVKKDTKVRPFLRYRKLCFAVSGVLILAGFAAMGINSASGGSILNYSMEFRGGTSTNVTFNEDMSLDRISSEVVPVVEKITGEAGTQTQKVAGTNEVIIKTRTLSVDEREELDQALVDTFGVDQEKITADSISGAISKEMKQDAVIAVVIATICMLLYIWFRFSNITFAASAVLALVHDVLVVVTFYAVFKWSVGSTFIACMLTIVGYSINATIVIFDRIRENMKLKKHTQTVEDVVNLSISQTLTRSINTSLTTFIMVFVLFLMGVSSIREFALPLMVGIVCGTYSSVCLTGSMWYLFNQKKEQKAAGERAAKTKKEK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKNKKGKSLIGLLLLLVAVGIFGYFGYSTMGAIKLGLDLAGGVSITYQAKEANPSSEDMADTIYKLQQRVQNYSTEAEVYQEGSNRINVDIPGVSDANAILQELGKPGSLVFLDSEFNQVLDGKQVSSAKAGMDDSSGVKEYVVALTFNEEGTKAFADATTKGVGKPIYIVYDGQPISAPNVKEPITGGQCRIDGMGSFEEAENLAATIRIGSLSLELEELRSNVVGAKLGQEAISTSLKAGAIGFGIVVVFMIFAYLIPGLAASIALCLYVGLILVLLAAFEVTLTLPGVAGIILSIGMAVDANVIIFTRIKEEIGMGKTVKSAIKTGFAKALSAIIDGNVTTLIAAAVLFWRGSGTVKGFASTLAIGIILSMFTALFVTKFALYCLFEAGLQDAKYYGVKKDTKVRPFLRYRKLCFAVSGVLILAGFAAMGINSASGGSILNYSMEFRGGTSTNVTFNEDMSLDRISSEVVPVVEKITGEAGTQTQKVAGTNEVIIKTRTLSVDEREELDQALVDTFGVDQEKITADSISGAISKEMKQDAVIAVVIATICMLLYIWFRFSNITFAASAVLALVHDVLVVVTFYAVFKWSVGSTFIACMLTIVGYSINATIVIFDRIRENMKLKKHTQTVEDVVNLSISQTLTRSINTSLTTFIMVFVLFLMGVSSIREFALPLMVGIVCGTYSSVCLTGSMWYLFNQKKEQKAAGERAAKTKKEK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGAACAAAAAAGGAAAGAGCCTCATAGGGCTGCTGCTCCTGCTTGTTGCTGTCGGTATTTTCGGTTATTTCGGATATTCGACAATGGGAGCAATCAAGCTGGGCCTGGATCTGGCCGGCGGAGTCAGCATTACCTACCAGGCAAAAGAGGCAAATCCGTCTTCTGAGGACATGGCGGATACGATTTATAAGCTGCAGCAGAGGGTGCAGAATTACAGCACCGAGGCGGAAGTTTACCAGGAAGGCAGCAACCGTATCAATGTAGATATTCCAGGCGTTTCCGATGCGAACGCGATCTTGCAGGAACTGGGCAAACCCGGCTCCCTTGTATTCCTTGATTCTGAGTTCAATCAGGTCCTGGACGGTAAACAGGTGAGCAGCGCCAAGGCCGGCATGGACGACAGCAGCGGAGTGAAGGAATATGTGGTTGCCTTGACCTTTAATGAAGAAGGTACAAAAGCGTTTGCCGATGCGACTACCAAAGGGGTCGGCAAGCCCATTTATATTGTATATGACGGCCAGCCAATTTCGGCTCCGAATGTAAAAGAACCGATTACAGGCGGACAGTGCCGTATCGACGGCATGGGCAGTTTTGAAGAGGCGGAGAACCTGGCTGCCACAATCCGAATCGGCTCCCTTTCATTGGAACTGGAAGAGCTGCGTTCTAACGTCGTAGGCGCAAAGCTTGGCCAGGAAGCGATTTCCACCAGCCTGAAGGCAGGCGCCATCGGTTTCGGCATCGTTGTTGTATTTATGATTTTTGCATACCTGATTCCGGGCCTTGCAGCATCTATCGCACTCTGCCTTTATGTGGGACTGATTCTTGTGCTGCTGGCAGCCTTTGAGGTAACATTAACTCTGCCGGGCGTTGCAGGTATTATCTTATCCATCGGTATGGCCGTGGATGCCAACGTTATTATCTTTACCCGTATCAAAGAAGAAATCGGAATGGGCAAGACAGTGAAATCTGCGATTAAGACAGGTTTTGCAAAGGCTCTGTCTGCCATCATCGACGGAAACGTTACAACGCTGATTGCGGCAGCCGTTCTTTTCTGGAGAGGCTCCGGTACGGTAAAAGGTTTTGCGTCCACACTGGCGATTGGTATCATCCTTTCCATGTTTACGGCTCTGTTCGTAACGAAATTTGCTCTCTACTGTCTGTTTGAGGCAGGTTTGCAGGATGCCAAATACTATGGCGTTAAGAAGGATACAAAGGTAAGGCCGTTCCTGAGATACAGAAAGCTGTGCTTCGCGGTTTCGGGTGTTTTGATTCTTGCCGGATTTGCGGCGATGGGAATTAACAGCGCTTCCGGCGGCTCAATTTTGAACTATAGTATGGAGTTCAGAGGCGGTACATCGACAAACGTAACGTTTAATGAGGATATGTCACTTGACCGGATATCTTCGGAGGTAGTGCCTGTTGTGGAGAAGATAACAGGGGAAGCGGGAACTCAGACACAGAAGGTAGCCGGAACCAATGAGGTAATCATTAAGACCAGGACTCTGAGCGTGGACGAGAGAGAAGAGCTGGATCAGGCTCTGGTTGATACCTTTGGCGTTGATCAGGAAAAGATCACGGCGGACAGTATCTCCGGTGCAATCAGCAAGGAGATGAAACAGGATGCGGTGATTGCCGTAGTGATTGCTACAATCTGTATGCTGCTTTATATCTGGTTCCGGTTCAGCAATATTACGTTTGCGGCAAGTGCGGTTCTGGCGCTGGTGCATGACGTACTCGTTGTCGTGACGTTCTACGCCGTCTTTAAATGGTCCGTGGGTTCCACGTTTATCGCATGTATGCTGACGATTGTCGGTTATTCCATCAATGCCACCATTGTTATATTTGACCGTATCCGTGAGAATATGAAGCTGAAAAAGCATACACAGACGGTGGAGGATGTTGTGAATTTAAGTATCAGCCAGACGCTGACGAGAAGTATCAATACCTCCCTGACAACATTTATCATGGTATTTGTTCTCTTCCTGATGGGAGTATCTTCCATCCGCGAGTTTGCACTTCCTCTGATGGTGGGTATTGTCTGCGGTACTTATTCTTCCGTATGCCTGACCGGCTCCATGTGGTACCTTTTCAATCAGAAAAAAGAACAGAAGGCGGCCGGAGAGCGGGCGGCAAAGACAAAGAAAGAGAAATAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 8146,
                        "end": 9543,
                        "strand": -1,
                        "locus_tag": "MLALJMBA_02075",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02075</span></strong><br>\n \n  GTP 3&#39;,8-cyclase<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02075</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">moaA_1</span><br>\n \n Location: 8,146 - 9,543,\n (total: 1398 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIHQYINNGFYIVLDVNSGSVHSVDPLLYDAIKLLSGRLADMKEPAPVPRKTEEEVAELLKEKYSADEIQEAFSDIQELIDREELFTADIYKDYVMDFKKRQTVVKALCLHIAHDCNLACRYCFAEEGEYHGRRALMSYEVGKKALDFLIANSGARRNLEVDFFGGEPLMNWEVVKQLVEYGRSQEELHNKKFRFTLTTNGVLLNDEIMEFSNREMSNVVLSLDGRQDVNDRMRPFRNGRGSYDLIVPKFQKFAKERGDRDYFIRGTFTRNNLDFADDVLHFADLGFEKMSVEPVVASPEEPYAIREEDLPQIMEEYDRLAEEYIKRHKEGRGFTFFHFMLDLNQGPCVAKRLSGCGSGTEYLAVTPWGDLYPCHQFVGNEEFLLGNVDEGVTKTEICNEFKLCNVYAKDKCRDCFARFYCSGGCAANSFNFHGSITDAYDIGCEMQKKRIECAIMIKAALAEEE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIHQYINNGFYIVLDVNSGSVHSVDPLLYDAIKLLSGRLADMKEPAPVPRKTEEEVAELLKEKYSADEIQEAFSDIQELIDREELFTADIYKDYVMDFKKRQTVVKALCLHIAHDCNLACRYCFAEEGEYHGRRALMSYEVGKKALDFLIANSGARRNLEVDFFGGEPLMNWEVVKQLVEYGRSQEELHNKKFRFTLTTNGVLLNDEIMEFSNREMSNVVLSLDGRQDVNDRMRPFRNGRGSYDLIVPKFQKFAKERGDRDYFIRGTFTRNNLDFADDVLHFADLGFEKMSVEPVVASPEEPYAIREEDLPQIMEEYDRLAEEYIKRHKEGRGFTFFHFMLDLNQGPCVAKRLSGCGSGTEYLAVTPWGDLYPCHQFVGNEEFLLGNVDEGVTKTEICNEFKLCNVYAKDKCRDCFARFYCSGGCAANSFNFHGSITDAYDIGCEMQKKRIECAIMIKAALAEEE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGATTCATCAATATATAAATAACGGTTTTTATATCGTTTTAGACGTTAACAGCGGTTCTGTCCATTCGGTGGATCCGCTCCTTTATGATGCAATTAAGCTTCTCTCGGGCAGGCTTGCCGATATGAAAGAGCCTGCACCCGTACCGCGAAAGACCGAGGAGGAAGTGGCGGAGCTCCTGAAGGAGAAATACAGTGCGGATGAGATTCAGGAAGCTTTTTCCGACATACAGGAATTAATTGACAGGGAGGAGCTTTTTACCGCCGATATTTACAAAGACTACGTGATGGATTTTAAAAAGAGGCAGACTGTTGTAAAAGCGCTCTGTCTGCACATTGCCCATGACTGTAATCTGGCCTGCCGTTATTGTTTTGCGGAAGAGGGGGAGTACCACGGACGCAGGGCGCTGATGAGCTATGAGGTCGGTAAAAAAGCGCTGGATTTTCTGATCGCAAATTCGGGCGCCCGAAGAAATCTGGAAGTGGATTTTTTCGGCGGAGAGCCGCTTATGAACTGGGAAGTGGTAAAGCAGCTTGTGGAATACGGACGTTCCCAGGAAGAGCTTCATAATAAGAAGTTCCGTTTTACGCTGACAACCAACGGCGTACTTTTAAACGACGAGATTATGGAATTTAGCAACAGGGAGATGAGCAACGTAGTTTTAAGCCTTGACGGCAGACAGGACGTCAATGACCGGATGCGTCCGTTCCGGAACGGCAGGGGAAGCTATGACCTGATAGTGCCGAAGTTCCAGAAATTTGCCAAAGAACGCGGTGACAGGGATTACTTTATCCGGGGGACCTTTACGAGAAATAACCTGGACTTTGCAGACGATGTGCTCCATTTTGCCGATCTTGGATTTGAAAAGATGTCGGTGGAGCCTGTGGTGGCCTCTCCGGAGGAACCCTATGCCATCCGGGAAGAAGACCTTCCGCAGATCATGGAGGAGTACGACAGGCTGGCTGAGGAATATATAAAGCGCCACAAAGAGGGAAGGGGCTTTACCTTTTTCCATTTTATGCTGGACTTGAACCAGGGGCCGTGCGTTGCGAAGCGGTTATCCGGCTGCGGTTCAGGAACCGAATACCTGGCTGTAACGCCATGGGGAGATCTCTACCCCTGTCATCAGTTTGTGGGAAATGAAGAATTTCTTCTCGGCAATGTGGACGAGGGTGTGACAAAGACGGAGATTTGTAATGAATTCAAGCTCTGTAATGTCTACGCAAAGGATAAATGCAGGGATTGTTTTGCGAGATTTTACTGCAGCGGCGGCTGTGCGGCCAATTCTTTTAATTTCCATGGCTCTATTACAGATGCTTATGATATCGGATGTGAAATGCAGAAAAAGCGGATCGAGTGTGCAATTATGATTAAAGCTGCTCTGGCTGAGGAAGAATAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 9697,
                        "end": 9843,
                        "strand": -1,
                        "locus_tag": "MLALJMBA_02076",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02076</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02076</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,697 - 9,843,\n (total: 147 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SCIFF<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR03973<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKHVKTLNTNTLKNSMKKGGCGECQTSCQSACKTSCTVGNQSCENQNR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKHVKTLNTNTLKNSMKKGGCGECQTSCQSACKTSCTVGNQSCENQNR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACACGTTAAAACATTAAACACAAACACATTAAAAAACAGCATGAAGAAGGGCGGCTGCGGCGAGTGCCAGACATCCTGCCAGTCTGCATGTAAGACATCTTGTACAGTAGGAAACCAGAGCTGCGAGAATCAGAACCGATAA\">Copy to clipboard</span><br>\n</div>"
                    }
                ],
                "clusters": [
                    {
                        "start": 8145,
                        "end": 9843,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 0,
                        "neighbouring_end": 9965,
                        "product": "ranthipeptide",
                        "height": 2,
                        "kind": "protocluster",
                        "prefix": ""
                    }
                ],
                "ttaCodons": [],
                "type": "ranthipeptide",
                "products": [
                    "ranthipeptide"
                ],
                "anchor": "r115c1"
            }
        ]
    },
    {
        "length": 18096,
        "seq_id": "NZ_KE992909.1",
        "regions": []
    },
    {
        "length": 26499,
        "seq_id": "NZ_KE992910.1",
        "regions": []
    },
    {
        "length": 27242,
        "seq_id": "NZ_KE992911.1",
        "regions": []
    },
    {
        "length": 20345,
        "seq_id": "NZ_KE992912.1",
        "regions": []
    },
    {
        "length": 4449,
        "seq_id": "NZ_KE992913.1",
        "regions": []
    },
    {
        "length": 13218,
        "seq_id": "NZ_KE992914.1",
        "regions": []
    },
    {
        "length": 17685,
        "seq_id": "NZ_KE992915.1",
        "regions": []
    },
    {
        "length": 57792,
        "seq_id": "NZ_KE992916.1",
        "regions": []
    },
    {
        "length": 34796,
        "seq_id": "NZ_KE992917.1",
        "regions": []
    },
    {
        "length": 36791,
        "seq_id": "NZ_KE992918.1",
        "regions": []
    },
    {
        "length": 8680,
        "seq_id": "NZ_KE992919.1",
        "regions": []
    },
    {
        "length": 37515,
        "seq_id": "NZ_KE992920.1",
        "regions": []
    },
    {
        "length": 8312,
        "seq_id": "NZ_KE992921.1",
        "regions": []
    },
    {
        "length": 17912,
        "seq_id": "NZ_KE992923.1",
        "regions": []
    },
    {
        "length": 24827,
        "seq_id": "NZ_KE992924.1",
        "regions": []
    },
    {
        "length": 10667,
        "seq_id": "NZ_KE992925.1",
        "regions": []
    },
    {
        "length": 38543,
        "seq_id": "NZ_KE992926.1",
        "regions": []
    },
    {
        "length": 17943,
        "seq_id": "NZ_KE992927.1",
        "regions": []
    },
    {
        "length": 16812,
        "seq_id": "NZ_KE992928.1",
        "regions": []
    },
    {
        "length": 27596,
        "seq_id": "NZ_KE992929.1",
        "regions": []
    },
    {
        "length": 19437,
        "seq_id": "NZ_KE992930.1",
        "regions": []
    },
    {
        "length": 6340,
        "seq_id": "NZ_KE992931.1",
        "regions": []
    },
    {
        "length": 40342,
        "seq_id": "NZ_KE992932.1",
        "regions": []
    },
    {
        "length": 18255,
        "seq_id": "NZ_KE992933.1",
        "regions": []
    },
    {
        "length": 45990,
        "seq_id": "NZ_KE992934.1",
        "regions": []
    },
    {
        "length": 20108,
        "seq_id": "NZ_KE992935.1",
        "regions": []
    },
    {
        "length": 1553,
        "seq_id": "NZ_KE992936.1",
        "regions": []
    },
    {
        "length": 27131,
        "seq_id": "NZ_KE992937.1",
        "regions": []
    },
    {
        "length": 23053,
        "seq_id": "NZ_KE992938.1",
        "regions": []
    },
    {
        "length": 8275,
        "seq_id": "NZ_KE992939.1",
        "regions": []
    },
    {
        "length": 11669,
        "seq_id": "NZ_KE992940.1",
        "regions": []
    },
    {
        "length": 1456,
        "seq_id": "NZ_KE992941.1",
        "regions": []
    },
    {
        "length": 1202,
        "seq_id": "NZ_KE992942.1",
        "regions": []
    },
    {
        "length": 1322,
        "seq_id": "NZ_KE992943.1",
        "regions": []
    },
    {
        "length": 2507,
        "seq_id": "NZ_KE992944.1",
        "regions": []
    },
    {
        "length": 14637,
        "seq_id": "NZ_KE992945.1",
        "regions": []
    },
    {
        "length": 83369,
        "seq_id": "NZ_KE992946.1",
        "regions": []
    },
    {
        "length": 37893,
        "seq_id": "NZ_KE992947.1",
        "regions": []
    },
    {
        "length": 1695,
        "seq_id": "NZ_KE992948.1",
        "regions": []
    },
    {
        "length": 23843,
        "seq_id": "NZ_KE992949.1",
        "regions": []
    },
    {
        "length": 12594,
        "seq_id": "NZ_KE992950.1",
        "regions": []
    },
    {
        "length": 24586,
        "seq_id": "NZ_KE992951.1",
        "regions": []
    },
    {
        "length": 5463,
        "seq_id": "NZ_KE992952.1",
        "regions": []
    },
    {
        "length": 21024,
        "seq_id": "NZ_KE992953.1",
        "regions": []
    },
    {
        "length": 2051,
        "seq_id": "NZ_KE992954.1",
        "regions": []
    },
    {
        "length": 22839,
        "seq_id": "NZ_KE992955.1",
        "regions": []
    },
    {
        "length": 5107,
        "seq_id": "NZ_KE992956.1",
        "regions": []
    },
    {
        "length": 10889,
        "seq_id": "NZ_KE992957.1",
        "regions": []
    },
    {
        "length": 4522,
        "seq_id": "NZ_KE992958.1",
        "regions": []
    },
    {
        "length": 27943,
        "seq_id": "NZ_KE992959.1",
        "regions": []
    },
    {
        "length": 18085,
        "seq_id": "NZ_KE992961.1",
        "regions": []
    },
    {
        "length": 2553,
        "seq_id": "NZ_KE992962.1",
        "regions": []
    },
    {
        "length": 43048,
        "seq_id": "NZ_KE992963.1",
        "regions": []
    },
    {
        "length": 9852,
        "seq_id": "NZ_KE992964.1",
        "regions": []
    },
    {
        "length": 14714,
        "seq_id": "NZ_KE992965.1",
        "regions": []
    },
    {
        "length": 2341,
        "seq_id": "NZ_KE992966.1",
        "regions": []
    },
    {
        "length": 44555,
        "seq_id": "NZ_KE992967.1",
        "regions": []
    },
    {
        "length": 37382,
        "seq_id": "NZ_KE992968.1",
        "regions": []
    },
    {
        "length": 35720,
        "seq_id": "NZ_KE992969.1",
        "regions": []
    },
    {
        "length": 26370,
        "seq_id": "NZ_KE992970.1",
        "regions": []
    },
    {
        "length": 3359,
        "seq_id": "NZ_KE992971.1",
        "regions": []
    },
    {
        "length": 23357,
        "seq_id": "NZ_KE992972.1",
        "regions": []
    },
    {
        "length": 2455,
        "seq_id": "NZ_KE992973.1",
        "regions": []
    },
    {
        "length": 18069,
        "seq_id": "NZ_KE992974.1",
        "regions": []
    },
    {
        "length": 4844,
        "seq_id": "NZ_KE992975.1",
        "regions": []
    },
    {
        "length": 14862,
        "seq_id": "NZ_KE992976.1",
        "regions": []
    },
    {
        "length": 4074,
        "seq_id": "NZ_KE992978.1",
        "regions": []
    },
    {
        "length": 3593,
        "seq_id": "NZ_KE992979.1",
        "regions": []
    },
    {
        "length": 25349,
        "seq_id": "NZ_KE992980.1",
        "regions": []
    },
    {
        "length": 12458,
        "seq_id": "NZ_KE992981.1",
        "regions": []
    },
    {
        "length": 8042,
        "seq_id": "NZ_KE992982.1",
        "regions": []
    },
    {
        "length": 6387,
        "seq_id": "NZ_KE992983.1",
        "regions": []
    },
    {
        "length": 9108,
        "seq_id": "NZ_KE992984.1",
        "regions": []
    },
    {
        "length": 12224,
        "seq_id": "NZ_KE992985.1",
        "regions": []
    },
    {
        "length": 8981,
        "seq_id": "NZ_KE992986.1",
        "regions": []
    },
    {
        "length": 18575,
        "seq_id": "NZ_KE992987.1",
        "regions": []
    },
    {
        "length": 8561,
        "seq_id": "NZ_KE992988.1",
        "regions": []
    },
    {
        "length": 8244,
        "seq_id": "NZ_KE992989.1",
        "regions": []
    },
    {
        "length": 16877,
        "seq_id": "NZ_KE992990.1",
        "regions": []
    },
    {
        "length": 10455,
        "seq_id": "NZ_KE992991.1",
        "regions": []
    },
    {
        "length": 32974,
        "seq_id": "NZ_KE992992.1",
        "regions": []
    },
    {
        "length": 14535,
        "seq_id": "NZ_KE992993.1",
        "regions": []
    },
    {
        "length": 32049,
        "seq_id": "NZ_KE992994.1",
        "regions": []
    },
    {
        "length": 29791,
        "seq_id": "NZ_KE992995.1",
        "regions": []
    },
    {
        "length": 15719,
        "seq_id": "NZ_KE992996.1",
        "regions": []
    },
    {
        "length": 76538,
        "seq_id": "NZ_KE992999.1",
        "regions": []
    },
    {
        "length": 24155,
        "seq_id": "NZ_KE993000.1",
        "regions": []
    },
    {
        "length": 18069,
        "seq_id": "NZ_KE993001.1",
        "regions": []
    },
    {
        "length": 39879,
        "seq_id": "NZ_KE993002.1",
        "regions": []
    },
    {
        "length": 19373,
        "seq_id": "NZ_KE993003.1",
        "regions": []
    },
    {
        "length": 16293,
        "seq_id": "NZ_KE993004.1",
        "regions": []
    },
    {
        "length": 2323,
        "seq_id": "NZ_KE993005.1",
        "regions": []
    },
    {
        "length": 11927,
        "seq_id": "NZ_KE993007.1",
        "regions": []
    },
    {
        "length": 17281,
        "seq_id": "NZ_KE993008.1",
        "regions": []
    },
    {
        "length": 1345,
        "seq_id": "NZ_KE993009.1",
        "regions": []
    },
    {
        "length": 6152,
        "seq_id": "NZ_KE993010.1",
        "regions": []
    },
    {
        "length": 28380,
        "seq_id": "NZ_KE993011.1",
        "regions": []
    },
    {
        "length": 22430,
        "seq_id": "NZ_KE993013.1",
        "regions": []
    },
    {
        "length": 5005,
        "seq_id": "NZ_KE993014.1",
        "regions": []
    },
    {
        "length": 40840,
        "seq_id": "NZ_KE993015.1",
        "regions": []
    },
    {
        "length": 23354,
        "seq_id": "NZ_KE993016.1",
        "regions": []
    },
    {
        "length": 22783,
        "seq_id": "NZ_KE993017.1",
        "regions": []
    },
    {
        "length": 1428,
        "seq_id": "NZ_KE993018.1",
        "regions": []
    },
    {
        "length": 9013,
        "seq_id": "NZ_KE993019.1",
        "regions": []
    },
    {
        "length": 1846,
        "seq_id": "NZ_KE993020.1",
        "regions": []
    },
    {
        "length": 32882,
        "seq_id": "NZ_KE993021.1",
        "regions": []
    },
    {
        "length": 10975,
        "seq_id": "NZ_KE993022.1",
        "regions": []
    },
    {
        "length": 11380,
        "seq_id": "NZ_KE993023.1",
        "regions": []
    },
    {
        "length": 53548,
        "seq_id": "NZ_KE993024.1",
        "regions": []
    },
    {
        "length": 18291,
        "seq_id": "NZ_KE993025.1",
        "regions": []
    },
    {
        "length": 2220,
        "seq_id": "NZ_KE993026.1",
        "regions": []
    },
    {
        "length": 16758,
        "seq_id": "NZ_KE993027.1",
        "regions": []
    },
    {
        "length": 44748,
        "seq_id": "NZ_KE993028.1",
        "regions": []
    },
    {
        "length": 1055,
        "seq_id": "NZ_KE993029.1",
        "regions": []
    },
    {
        "length": 1914,
        "seq_id": "NZ_KE993030.1",
        "regions": []
    },
    {
        "length": 60386,
        "seq_id": "NZ_KE993033.1",
        "regions": []
    },
    {
        "length": 30142,
        "seq_id": "NZ_KE993034.1",
        "regions": []
    },
    {
        "length": 2109,
        "seq_id": "NZ_KE993035.1",
        "regions": []
    },
    {
        "length": 20206,
        "seq_id": "NZ_KE993036.1",
        "regions": []
    },
    {
        "length": 5321,
        "seq_id": "NZ_KE993037.1",
        "regions": []
    },
    {
        "length": 55183,
        "seq_id": "NZ_KE993038.1",
        "regions": []
    },
    {
        "length": 1383,
        "seq_id": "NZ_KE993039.1",
        "regions": []
    },
    {
        "length": 3183,
        "seq_id": "NZ_KE993040.1",
        "regions": []
    },
    {
        "length": 18196,
        "seq_id": "NZ_KE993041.1",
        "regions": []
    },
    {
        "length": 2151,
        "seq_id": "NZ_KE993042.1",
        "regions": []
    },
    {
        "length": 12814,
        "seq_id": "NZ_KE993043.1",
        "regions": []
    },
    {
        "length": 26512,
        "seq_id": "NZ_KE993044.1",
        "regions": []
    },
    {
        "length": 16719,
        "seq_id": "NZ_KE993045.1",
        "regions": []
    },
    {
        "length": 5246,
        "seq_id": "NZ_KE993046.1",
        "regions": []
    },
    {
        "length": 15548,
        "seq_id": "NZ_KE993047.1",
        "regions": []
    },
    {
        "length": 8267,
        "seq_id": "NZ_KE993049.1",
        "regions": []
    },
    {
        "length": 29135,
        "seq_id": "NZ_KE993050.1",
        "regions": []
    },
    {
        "length": 27461,
        "seq_id": "NZ_KE993051.1",
        "regions": []
    },
    {
        "length": 2860,
        "seq_id": "NZ_KE993052.1",
        "regions": []
    },
    {
        "length": 24520,
        "seq_id": "NZ_KE993053.1",
        "regions": []
    }
];
var all_regions = {
    "order": [
        "r115c1"
    ],
    "r115c1": {
        "start": 1,
        "end": 9965,
        "idx": 1,
        "orfs": [
            {
                "start": 310,
                "end": 900,
                "strand": -1,
                "locus_tag": "MLALJMBA_02066",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02066</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02066</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 310 - 900,\n (total: 591 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKKKHWYDYLWIWSIIYFTLGFFNILFAWLGMIDFLVPVFIAVFGRNKWFCNNLCGRGQLFALLGGKYKCSRNRPTPRFLVSPWFRYGFLAFFMAMFGNMVFQTWLVAAGASGLREALKLFWTFKVPWGWTYTAGMVPDWVAQYSFGFYSLMLTSLLLGLIMMVLYKPRSWCTFCPMGTMTQGICKLGSRGETQDS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKKKHWYDYLWIWSIIYFTLGFFNILFAWLGMIDFLVPVFIAVFGRNKWFCNNLCGRGQLFALLGGKYKCSRNRPTPRFLVSPWFRYGFLAFFMAMFGNMVFQTWLVAAGASGLREALKLFWTFKVPWGWTYTAGMVPDWVAQYSFGFYSLMLTSLLLGLIMMVLYKPRSWCTFCPMGTMTQGICKLGSRGETQDS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAAAGAAACACTGGTATGACTATCTCTGGATATGGTCCATCATTTATTTTACACTGGGCTTCTTTAATATTTTATTTGCATGGCTTGGAATGATCGATTTTCTTGTGCCTGTTTTTATCGCTGTTTTCGGGAGAAATAAGTGGTTTTGCAACAATCTCTGCGGCCGCGGCCAATTGTTTGCGCTGCTGGGGGGAAAATATAAATGTTCCAGGAACAGGCCGACGCCCCGGTTTCTCGTATCGCCCTGGTTCCGTTACGGTTTTCTGGCCTTTTTCATGGCTATGTTCGGAAATATGGTGTTTCAGACCTGGCTTGTGGCGGCGGGGGCTTCGGGACTCAGGGAGGCGCTCAAACTGTTCTGGACCTTTAAAGTTCCATGGGGCTGGACTTACACCGCAGGAATGGTGCCGGACTGGGTGGCCCAGTACAGCTTCGGGTTCTACAGCCTGATGCTGACATCACTCTTACTTGGCCTGATTATGATGGTTCTCTATAAACCGAGAAGCTGGTGTACTTTCTGTCCGATGGGAACGATGACCCAGGGGATTTGCAAGCTGGGGAGCAGAGGGGAGACGCAGGACAGTTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 897,
                "end": 1109,
                "strand": -1,
                "locus_tag": "MLALJMBA_02067",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02067</span></strong><br>\n \n  NAD(P)H-quinone oxidoreductase subunit I, chloroplastic<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02067</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">ndhI_1</span><br>\n \n Location: 897 - 1,109,\n (total: 213 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSVKTKRSVSVNLKRCVACGACCKVCPREAIAVSGGCYAAADLEKCVGCGLCEKLCPAGALSILIREAQL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSVKTKRSVSVNLKRCVACGACCKVCPREAIAVSGGCYAAADLEKCVGCGLCEKLCPAGALSILIREAQL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCTGTTAAAACAAAACGAAGTGTATCGGTGAACCTAAAACGATGCGTCGCGTGCGGAGCATGCTGTAAGGTCTGCCCCAGGGAGGCGATCGCGGTATCAGGAGGCTGCTATGCGGCTGCGGATTTGGAGAAGTGCGTCGGCTGCGGTCTGTGTGAAAAGCTGTGCCCGGCCGGTGCGCTCTCGATTCTTATCAGGGAGGCACAGCTATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1356,
                "end": 2225,
                "strand": 1,
                "locus_tag": "MLALJMBA_02068",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02068</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02068</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,356 - 2,225,\n (total: 870 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1148:hypothetical protein (Score: 68.3; E-value: 1.8e-20)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSFSENLQYLRKKQNLTQEQFAEQMEVSRQAVSKWESGQSYPEMEKLLQICEQFGCSMDSLIKGDVTEAAKEDSTGYNRHMNRYSIMVSSAVALIIFSVAIIASLDGIVSEAVTSIILFVLIGIAVYILIIAGISHQYYRRRYPDIDNFYTEEQHANFNRIFAIAIASGVSLIVFSLCLNIWLEYTVIPYSEQISGGVFLLCTAVAVGIFTFFGMQKDKYDIGKYNQENRPEAPGKKHLASKLCGVIMLLATALFLFLGLSFDMFRSAAVIYPVAGIFCGIVCLLLSDK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSFSENLQYLRKKQNLTQEQFAEQMEVSRQAVSKWESGQSYPEMEKLLQICEQFGCSMDSLIKGDVTEAAKEDSTGYNRHMNRYSIMVSSAVALIIFSVAIIASLDGIVSEAVTSIILFVLIGIAVYILIIAGISHQYYRRRYPDIDNFYTEEQHANFNRIFAIAIASGVSLIVFSLCLNIWLEYTVIPYSEQISGGVFLLCTAVAVGIFTFFGMQKDKYDIGKYNQENRPEAPGKKHLASKLCGVIMLLATALFLFLGLSFDMFRSAAVIYPVAGIFCGIVCLLLSDK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTTTTTCAGAGAATTTACAATACTTAAGAAAAAAACAAAATTTGACACAGGAGCAGTTTGCCGAACAGATGGAGGTATCGAGACAGGCCGTCTCCAAATGGGAATCAGGCCAGTCTTACCCGGAGATGGAAAAACTGCTTCAGATATGCGAGCAGTTCGGATGTTCCATGGACAGCCTCATCAAAGGCGATGTGACAGAAGCGGCAAAAGAAGATTCGACAGGCTATAACCGCCATATGAACCGCTATTCCATCATGGTTTCCTCTGCCGTTGCCCTGATCATTTTTTCGGTCGCAATCATCGCCTCGCTGGACGGAATCGTAAGCGAAGCCGTTACAAGCATTATCCTGTTCGTATTGATCGGAATTGCCGTATATATCCTGATAATAGCCGGCATCAGCCATCAGTACTACCGCAGGCGTTATCCCGATATCGATAATTTCTACACGGAAGAACAGCATGCCAATTTCAACCGTATTTTTGCAATTGCCATAGCTTCCGGGGTCAGTCTCATTGTTTTTTCTCTCTGCCTGAACATCTGGCTTGAGTACACCGTTATCCCTTATTCTGAGCAGATAAGCGGAGGCGTTTTTCTTCTCTGTACCGCCGTGGCCGTCGGTATTTTCACTTTCTTTGGCATGCAGAAGGACAAATACGACATCGGCAAATATAACCAGGAAAACCGTCCGGAGGCTCCCGGCAAAAAGCACCTGGCGAGCAAGCTGTGCGGCGTCATCATGCTCCTGGCGACAGCTCTCTTCCTGTTCCTCGGCCTTTCATTTGATATGTTCCGGTCCGCAGCCGTCATTTATCCGGTCGCAGGAATCTTCTGCGGTATCGTCTGCCTGCTGCTGAGCGATAAATAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 2336,
                "end": 2761,
                "strand": -1,
                "locus_tag": "MLALJMBA_02069",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02069</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02069</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,336 - 2,761,\n (total: 426 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MEKRYADAAIFYAAAAMVFGVFYREFTKFNGFTGKTNLSVMHTHYFLLGMFFFLILMLLEKNFRFSGGEKIGIILTVYHIGLNVTALGFLLRGLTQVWGTELSRGMDASISGLSGVGHIMLGISMILLLLKIRKKTVLEKK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MEKRYADAAIFYAAAAMVFGVFYREFTKFNGFTGKTNLSVMHTHYFLLGMFFFLILMLLEKNFRFSGGEKIGIILTVYHIGLNVTALGFLLRGLTQVWGTELSRGMDASISGLSGVGHIMLGISMILLLLKIRKKTVLEKK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAAAAACGTTATGCGGATGCAGCCATATTCTATGCAGCGGCTGCCATGGTATTCGGTGTGTTTTACAGGGAGTTTACAAAATTTAACGGTTTTACCGGAAAAACTAATTTATCTGTCATGCATACACATTATTTTCTGTTGGGAATGTTTTTCTTTCTCATACTGATGCTGCTTGAAAAGAATTTCCGGTTTTCCGGCGGGGAGAAGATTGGAATAATTCTGACAGTCTATCACATAGGTTTGAATGTCACCGCCCTCGGTTTTCTTTTAAGGGGTCTGACACAGGTATGGGGTACCGAACTCAGCAGGGGGATGGATGCTTCCATATCGGGCCTTTCCGGTGTGGGCCATATTATGCTGGGAATCAGCATGATTCTGTTGTTGCTGAAGATCAGAAAAAAGACGGTCTTAGAAAAAAAGTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 2777,
                "end": 3454,
                "strand": -1,
                "locus_tag": "MLALJMBA_02070",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02070</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02070</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,777 - 3,454,\n (total: 678 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAQAIAETVFDILYLGFALITGLTMLTKGKSRIVKMAGWMTALLGAGDSFHLVPRSYALWTTGMEANAAALGIGKFITSVTMTVFYLILYYIWRERYQIRERKTLTGVMWFLACLRIGFCLLPQNEWLSYHQPLSYGILRNIPFAIMGIIIIVIFAAEAGKKADPVFWFMPLAAGLSFGFYLPVVLFSGAVPAVGMLMIPKTLAYVWMIWMARRLYKEETIIRHT&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAQAIAETVFDILYLGFALITGLTMLTKGKSRIVKMAGWMTALLGAGDSFHLVPRSYALWTTGMEANAAALGIGKFITSVTMTVFYLILYYIWRERYQIRERKTLTGVMWFLACLRIGFCLLPQNEWLSYHQPLSYGILRNIPFAIMGIIIIVIFAAEAGKKADPVFWFMPLAAGLSFGFYLPVVLFSGAVPAVGMLMIPKTLAYVWMIWMARRLYKEETIIRHT\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCACAGGCGATTGCTGAAACAGTTTTTGACATTTTATATCTTGGTTTTGCCCTGATAACAGGACTGACTATGCTGACAAAAGGAAAGAGCCGGATCGTAAAAATGGCAGGATGGATGACGGCGCTGCTGGGGGCAGGGGATTCCTTTCATCTGGTACCGCGTTCCTACGCACTTTGGACAACAGGGATGGAAGCAAATGCAGCCGCATTGGGGATTGGGAAATTTATTACGTCTGTCACGATGACGGTTTTTTATCTGATTTTATATTATATCTGGCGTGAGCGTTACCAGATTCGGGAACGTAAGACACTTACCGGTGTAATGTGGTTTTTAGCATGCCTGAGGATTGGATTTTGTCTTCTGCCTCAGAACGAGTGGCTGTCCTATCACCAGCCTCTGTCTTATGGGATACTGCGAAATATCCCATTTGCGATAATGGGAATTATCATTATCGTAATCTTTGCCGCAGAGGCCGGGAAAAAAGCGGATCCGGTGTTCTGGTTTATGCCTTTGGCGGCGGGACTTTCCTTTGGTTTCTACCTGCCCGTCGTATTGTTCAGCGGCGCAGTACCGGCCGTGGGCATGCTGATGATTCCAAAGACACTGGCTTACGTCTGGATGATTTGGATGGCGAGACGGCTTTACAAAGAAGAAACAATAATCAGGCATACATAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 3474,
                "end": 4073,
                "strand": -1,
                "locus_tag": "MLALJMBA_02071",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02071</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02071</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,474 - 4,073,\n (total: 600 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MYSIYEHVHLNEKGDDTVRKKDDSLRGALIDYARELAEKEGPEAVNIRSLAGKAGIATGTVYNYFSCKDEILLALTEEYWRKTLADMRAAVTAPSFCGQLEEIFTFLRERIDSSAGMLMHSLGNVRETGQERMESMQEVLEAAMVYRMEQDPGIRSDIWDETFTKRDYARFIMANMMLLLREHPYDFRFFLEIVKRTVY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MYSIYEHVHLNEKGDDTVRKKDDSLRGALIDYARELAEKEGPEAVNIRSLAGKAGIATGTVYNYFSCKDEILLALTEEYWRKTLADMRAAVTAPSFCGQLEEIFTFLRERIDSSAGMLMHSLGNVRETGQERMESMQEVLEAAMVYRMEQDPGIRSDIWDETFTKRDYARFIMANMMLLLREHPYDFRFFLEIVKRTVY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTATAGTATATATGAACATGTTCATTTAAATGAAAAAGGGGATGATACGGTGCGGAAAAAAGACGACAGCCTGAGGGGGGCACTGATTGACTATGCCCGGGAACTGGCGGAGAAAGAGGGGCCTGAGGCAGTCAATATACGCTCTCTGGCCGGGAAAGCCGGGATTGCGACGGGCACGGTATATAATTATTTTTCATGTAAAGACGAAATCCTCCTGGCTCTCACGGAAGAATACTGGAGAAAGACCTTGGCCGATATGAGGGCGGCAGTCACGGCCCCCTCATTCTGCGGGCAGCTGGAGGAAATTTTTACTTTTTTACGGGAGCGTATCGACAGCTCCGCCGGAATGCTGATGCACAGCCTCGGGAATGTCAGGGAGACAGGGCAGGAGAGAATGGAATCCATGCAGGAGGTTCTGGAAGCCGCAATGGTGTATCGGATGGAGCAGGATCCGGGCATACGCAGTGATATCTGGGACGAAACATTTACAAAGAGAGATTATGCCCGTTTTATTATGGCGAATATGATGCTGCTGCTCAGGGAGCATCCATATGATTTCCGGTTTTTTCTGGAAATAGTCAAACGGACCGTTTATTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 4418,
                "end": 4690,
                "strand": -1,
                "locus_tag": "MLALJMBA_02072",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02072</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02072</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,418 - 4,690,\n (total: 273 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGTAGWVLYFVFIIGLMYFIAIRPQQKEKKKMQELMAGVAVGDSVLTSSGFYGVIIDMTDDTVIVEFGSNKNCRIPMRKDAIVQVEKPEL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGTAGWVLYFVFIIGLMYFIAIRPQQKEKKKMQELMAGVAVGDSVLTSSGFYGVIIDMTDDTVIVEFGSNKNCRIPMRKDAIVQVEKPEL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGCACAGCGGGCTGGGTACTATATTTTGTCTTTATCATAGGACTTATGTACTTTATTGCGATCAGACCACAGCAGAAGGAAAAGAAAAAAATGCAGGAGCTGATGGCAGGTGTCGCAGTAGGCGACAGCGTTTTAACATCCAGTGGATTTTACGGCGTAATCATCGACATGACAGATGATACGGTTATCGTAGAATTCGGCAGCAACAAGAACTGCCGTATTCCTATGCGCAAGGATGCAATTGTTCAGGTTGAGAAACCGGAACTGTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 4780,
                "end": 5922,
                "strand": -1,
                "locus_tag": "MLALJMBA_02073",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02073</span></strong><br>\n \n  Queuine tRNA-ribosyltransferase<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02073</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">tgt</span><br>\n \n Location: 4,780 - 5,922,\n (total: 1143 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MEYKILYKDGRAKRAEMKTVHGTVQTPVFMNVGTVGAIKGAVSTDDLKEIGTQVELSNTYHLHVRTGDKLIKQFGGLHKFMNWDRPILTDSGGFQVFSLSGLRKIKEEGVYFNSHIDGRKIFMGPEESMQIQSNLGSTIAMAFDECPSSVASREYVQASVDRTTRWLERCREEMKRLNAQPDTVNREQLLFGINQGAIYEDIRIGHAKTISKMELDGYAVGGLAVGETHEEMYRILDAVVPHLPEDKPTYLMGVGTPANILEAVDRGVDFFDCVYPTRNGRHSHVYTNHGKMNLLNAKYELDKKPIEEGCGCPACRSYSRAYIRHLFKAKEMLGMRLCVLHNLYFYNKMMEEIRDAIEHHRYAEYKTAKLAGMMAGEEAK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MEYKILYKDGRAKRAEMKTVHGTVQTPVFMNVGTVGAIKGAVSTDDLKEIGTQVELSNTYHLHVRTGDKLIKQFGGLHKFMNWDRPILTDSGGFQVFSLSGLRKIKEEGVYFNSHIDGRKIFMGPEESMQIQSNLGSTIAMAFDECPSSVASREYVQASVDRTTRWLERCREEMKRLNAQPDTVNREQLLFGINQGAIYEDIRIGHAKTISKMELDGYAVGGLAVGETHEEMYRILDAVVPHLPEDKPTYLMGVGTPANILEAVDRGVDFFDCVYPTRNGRHSHVYTNHGKMNLLNAKYELDKKPIEEGCGCPACRSYSRAYIRHLFKAKEMLGMRLCVLHNLYFYNKMMEEIRDAIEHHRYAEYKTAKLAGMMAGEEAK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGAGTATAAGATTCTTTACAAAGACGGACGCGCGAAACGGGCAGAGATGAAAACCGTCCATGGAACTGTCCAGACACCTGTTTTCATGAATGTGGGAACTGTGGGGGCGATAAAGGGAGCCGTATCTACCGACGATCTGAAGGAAATCGGAACACAGGTAGAGTTGTCCAACACCTACCATCTGCACGTGAGAACCGGTGACAAGCTGATTAAGCAGTTTGGCGGACTTCATAAATTCATGAACTGGGACAGGCCGATTCTGACGGATTCCGGCGGTTTTCAGGTATTTTCCCTGTCGGGACTTCGAAAGATAAAGGAAGAGGGCGTTTATTTTAACTCTCATATCGACGGCAGGAAGATATTCATGGGTCCGGAGGAGAGCATGCAGATCCAGTCCAATCTGGGCTCCACAATCGCAATGGCATTTGATGAATGTCCGTCCAGCGTGGCTTCAAGGGAATACGTCCAGGCCTCGGTAGACAGAACCACAAGATGGCTTGAACGCTGCCGGGAAGAGATGAAACGCCTGAATGCTCAGCCGGATACGGTGAACCGTGAGCAGCTCCTCTTTGGAATCAATCAGGGAGCAATTTACGAGGATATCCGCATCGGGCATGCAAAGACAATCAGCAAGATGGAGCTGGACGGCTATGCTGTGGGCGGCCTGGCCGTGGGTGAAACCCATGAGGAGATGTACCGTATCCTCGATGCGGTGGTTCCCCATCTTCCGGAGGATAAGCCTACGTACCTGATGGGGGTCGGAACGCCTGCCAATATTTTAGAGGCGGTGGACCGCGGCGTTGATTTCTTTGACTGCGTGTATCCGACCAGAAACGGCCGGCACAGCCATGTCTATACAAACCATGGCAAGATGAATCTGCTGAATGCAAAATATGAACTGGATAAAAAGCCGATTGAAGAGGGCTGCGGCTGCCCGGCATGCCGTTCCTACAGCAGGGCCTATATAAGACATCTGTTTAAGGCAAAAGAAATGCTCGGGATGCGATTATGTGTATTGCATAATTTATATTTTTATAATAAAATGATGGAAGAGATTCGCGACGCAATCGAACATCACCGTTATGCCGAATATAAGACTGCAAAGCTTGCCGGCATGATGGCCGGAGAGGAAGCAAAATAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 5926,
                "end": 8082,
                "strand": -1,
                "locus_tag": "MLALJMBA_02074",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02074</span></strong><br>\n \n  Protein translocase subunit SecDF<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02074</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">secDF_2</span><br>\n \n Location: 5,926 - 8,082,\n (total: 2157 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKNKKGKSLIGLLLLLVAVGIFGYFGYSTMGAIKLGLDLAGGVSITYQAKEANPSSEDMADTIYKLQQRVQNYSTEAEVYQEGSNRINVDIPGVSDANAILQELGKPGSLVFLDSEFNQVLDGKQVSSAKAGMDDSSGVKEYVVALTFNEEGTKAFADATTKGVGKPIYIVYDGQPISAPNVKEPITGGQCRIDGMGSFEEAENLAATIRIGSLSLELEELRSNVVGAKLGQEAISTSLKAGAIGFGIVVVFMIFAYLIPGLAASIALCLYVGLILVLLAAFEVTLTLPGVAGIILSIGMAVDANVIIFTRIKEEIGMGKTVKSAIKTGFAKALSAIIDGNVTTLIAAAVLFWRGSGTVKGFASTLAIGIILSMFTALFVTKFALYCLFEAGLQDAKYYGVKKDTKVRPFLRYRKLCFAVSGVLILAGFAAMGINSASGGSILNYSMEFRGGTSTNVTFNEDMSLDRISSEVVPVVEKITGEAGTQTQKVAGTNEVIIKTRTLSVDEREELDQALVDTFGVDQEKITADSISGAISKEMKQDAVIAVVIATICMLLYIWFRFSNITFAASAVLALVHDVLVVVTFYAVFKWSVGSTFIACMLTIVGYSINATIVIFDRIRENMKLKKHTQTVEDVVNLSISQTLTRSINTSLTTFIMVFVLFLMGVSSIREFALPLMVGIVCGTYSSVCLTGSMWYLFNQKKEQKAAGERAAKTKKEK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKNKKGKSLIGLLLLLVAVGIFGYFGYSTMGAIKLGLDLAGGVSITYQAKEANPSSEDMADTIYKLQQRVQNYSTEAEVYQEGSNRINVDIPGVSDANAILQELGKPGSLVFLDSEFNQVLDGKQVSSAKAGMDDSSGVKEYVVALTFNEEGTKAFADATTKGVGKPIYIVYDGQPISAPNVKEPITGGQCRIDGMGSFEEAENLAATIRIGSLSLELEELRSNVVGAKLGQEAISTSLKAGAIGFGIVVVFMIFAYLIPGLAASIALCLYVGLILVLLAAFEVTLTLPGVAGIILSIGMAVDANVIIFTRIKEEIGMGKTVKSAIKTGFAKALSAIIDGNVTTLIAAAVLFWRGSGTVKGFASTLAIGIILSMFTALFVTKFALYCLFEAGLQDAKYYGVKKDTKVRPFLRYRKLCFAVSGVLILAGFAAMGINSASGGSILNYSMEFRGGTSTNVTFNEDMSLDRISSEVVPVVEKITGEAGTQTQKVAGTNEVIIKTRTLSVDEREELDQALVDTFGVDQEKITADSISGAISKEMKQDAVIAVVIATICMLLYIWFRFSNITFAASAVLALVHDVLVVVTFYAVFKWSVGSTFIACMLTIVGYSINATIVIFDRIRENMKLKKHTQTVEDVVNLSISQTLTRSINTSLTTFIMVFVLFLMGVSSIREFALPLMVGIVCGTYSSVCLTGSMWYLFNQKKEQKAAGERAAKTKKEK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGAACAAAAAAGGAAAGAGCCTCATAGGGCTGCTGCTCCTGCTTGTTGCTGTCGGTATTTTCGGTTATTTCGGATATTCGACAATGGGAGCAATCAAGCTGGGCCTGGATCTGGCCGGCGGAGTCAGCATTACCTACCAGGCAAAAGAGGCAAATCCGTCTTCTGAGGACATGGCGGATACGATTTATAAGCTGCAGCAGAGGGTGCAGAATTACAGCACCGAGGCGGAAGTTTACCAGGAAGGCAGCAACCGTATCAATGTAGATATTCCAGGCGTTTCCGATGCGAACGCGATCTTGCAGGAACTGGGCAAACCCGGCTCCCTTGTATTCCTTGATTCTGAGTTCAATCAGGTCCTGGACGGTAAACAGGTGAGCAGCGCCAAGGCCGGCATGGACGACAGCAGCGGAGTGAAGGAATATGTGGTTGCCTTGACCTTTAATGAAGAAGGTACAAAAGCGTTTGCCGATGCGACTACCAAAGGGGTCGGCAAGCCCATTTATATTGTATATGACGGCCAGCCAATTTCGGCTCCGAATGTAAAAGAACCGATTACAGGCGGACAGTGCCGTATCGACGGCATGGGCAGTTTTGAAGAGGCGGAGAACCTGGCTGCCACAATCCGAATCGGCTCCCTTTCATTGGAACTGGAAGAGCTGCGTTCTAACGTCGTAGGCGCAAAGCTTGGCCAGGAAGCGATTTCCACCAGCCTGAAGGCAGGCGCCATCGGTTTCGGCATCGTTGTTGTATTTATGATTTTTGCATACCTGATTCCGGGCCTTGCAGCATCTATCGCACTCTGCCTTTATGTGGGACTGATTCTTGTGCTGCTGGCAGCCTTTGAGGTAACATTAACTCTGCCGGGCGTTGCAGGTATTATCTTATCCATCGGTATGGCCGTGGATGCCAACGTTATTATCTTTACCCGTATCAAAGAAGAAATCGGAATGGGCAAGACAGTGAAATCTGCGATTAAGACAGGTTTTGCAAAGGCTCTGTCTGCCATCATCGACGGAAACGTTACAACGCTGATTGCGGCAGCCGTTCTTTTCTGGAGAGGCTCCGGTACGGTAAAAGGTTTTGCGTCCACACTGGCGATTGGTATCATCCTTTCCATGTTTACGGCTCTGTTCGTAACGAAATTTGCTCTCTACTGTCTGTTTGAGGCAGGTTTGCAGGATGCCAAATACTATGGCGTTAAGAAGGATACAAAGGTAAGGCCGTTCCTGAGATACAGAAAGCTGTGCTTCGCGGTTTCGGGTGTTTTGATTCTTGCCGGATTTGCGGCGATGGGAATTAACAGCGCTTCCGGCGGCTCAATTTTGAACTATAGTATGGAGTTCAGAGGCGGTACATCGACAAACGTAACGTTTAATGAGGATATGTCACTTGACCGGATATCTTCGGAGGTAGTGCCTGTTGTGGAGAAGATAACAGGGGAAGCGGGAACTCAGACACAGAAGGTAGCCGGAACCAATGAGGTAATCATTAAGACCAGGACTCTGAGCGTGGACGAGAGAGAAGAGCTGGATCAGGCTCTGGTTGATACCTTTGGCGTTGATCAGGAAAAGATCACGGCGGACAGTATCTCCGGTGCAATCAGCAAGGAGATGAAACAGGATGCGGTGATTGCCGTAGTGATTGCTACAATCTGTATGCTGCTTTATATCTGGTTCCGGTTCAGCAATATTACGTTTGCGGCAAGTGCGGTTCTGGCGCTGGTGCATGACGTACTCGTTGTCGTGACGTTCTACGCCGTCTTTAAATGGTCCGTGGGTTCCACGTTTATCGCATGTATGCTGACGATTGTCGGTTATTCCATCAATGCCACCATTGTTATATTTGACCGTATCCGTGAGAATATGAAGCTGAAAAAGCATACACAGACGGTGGAGGATGTTGTGAATTTAAGTATCAGCCAGACGCTGACGAGAAGTATCAATACCTCCCTGACAACATTTATCATGGTATTTGTTCTCTTCCTGATGGGAGTATCTTCCATCCGCGAGTTTGCACTTCCTCTGATGGTGGGTATTGTCTGCGGTACTTATTCTTCCGTATGCCTGACCGGCTCCATGTGGTACCTTTTCAATCAGAAAAAAGAACAGAAGGCGGCCGGAGAGCGGGCGGCAAAGACAAAGAAAGAGAAATAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 8146,
                "end": 9543,
                "strand": -1,
                "locus_tag": "MLALJMBA_02075",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02075</span></strong><br>\n \n  GTP 3&#39;,8-cyclase<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02075</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">moaA_1</span><br>\n \n Location: 8,146 - 9,543,\n (total: 1398 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: Ranthipeptide_rSAM_RRE<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: PF04055<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR04085<br>\n \n  biosynthetic-additional (rule-based-clusters) Fer4_12<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIHQYINNGFYIVLDVNSGSVHSVDPLLYDAIKLLSGRLADMKEPAPVPRKTEEEVAELLKEKYSADEIQEAFSDIQELIDREELFTADIYKDYVMDFKKRQTVVKALCLHIAHDCNLACRYCFAEEGEYHGRRALMSYEVGKKALDFLIANSGARRNLEVDFFGGEPLMNWEVVKQLVEYGRSQEELHNKKFRFTLTTNGVLLNDEIMEFSNREMSNVVLSLDGRQDVNDRMRPFRNGRGSYDLIVPKFQKFAKERGDRDYFIRGTFTRNNLDFADDVLHFADLGFEKMSVEPVVASPEEPYAIREEDLPQIMEEYDRLAEEYIKRHKEGRGFTFFHFMLDLNQGPCVAKRLSGCGSGTEYLAVTPWGDLYPCHQFVGNEEFLLGNVDEGVTKTEICNEFKLCNVYAKDKCRDCFARFYCSGGCAANSFNFHGSITDAYDIGCEMQKKRIECAIMIKAALAEEE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIHQYINNGFYIVLDVNSGSVHSVDPLLYDAIKLLSGRLADMKEPAPVPRKTEEEVAELLKEKYSADEIQEAFSDIQELIDREELFTADIYKDYVMDFKKRQTVVKALCLHIAHDCNLACRYCFAEEGEYHGRRALMSYEVGKKALDFLIANSGARRNLEVDFFGGEPLMNWEVVKQLVEYGRSQEELHNKKFRFTLTTNGVLLNDEIMEFSNREMSNVVLSLDGRQDVNDRMRPFRNGRGSYDLIVPKFQKFAKERGDRDYFIRGTFTRNNLDFADDVLHFADLGFEKMSVEPVVASPEEPYAIREEDLPQIMEEYDRLAEEYIKRHKEGRGFTFFHFMLDLNQGPCVAKRLSGCGSGTEYLAVTPWGDLYPCHQFVGNEEFLLGNVDEGVTKTEICNEFKLCNVYAKDKCRDCFARFYCSGGCAANSFNFHGSITDAYDIGCEMQKKRIECAIMIKAALAEEE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGATTCATCAATATATAAATAACGGTTTTTATATCGTTTTAGACGTTAACAGCGGTTCTGTCCATTCGGTGGATCCGCTCCTTTATGATGCAATTAAGCTTCTCTCGGGCAGGCTTGCCGATATGAAAGAGCCTGCACCCGTACCGCGAAAGACCGAGGAGGAAGTGGCGGAGCTCCTGAAGGAGAAATACAGTGCGGATGAGATTCAGGAAGCTTTTTCCGACATACAGGAATTAATTGACAGGGAGGAGCTTTTTACCGCCGATATTTACAAAGACTACGTGATGGATTTTAAAAAGAGGCAGACTGTTGTAAAAGCGCTCTGTCTGCACATTGCCCATGACTGTAATCTGGCCTGCCGTTATTGTTTTGCGGAAGAGGGGGAGTACCACGGACGCAGGGCGCTGATGAGCTATGAGGTCGGTAAAAAAGCGCTGGATTTTCTGATCGCAAATTCGGGCGCCCGAAGAAATCTGGAAGTGGATTTTTTCGGCGGAGAGCCGCTTATGAACTGGGAAGTGGTAAAGCAGCTTGTGGAATACGGACGTTCCCAGGAAGAGCTTCATAATAAGAAGTTCCGTTTTACGCTGACAACCAACGGCGTACTTTTAAACGACGAGATTATGGAATTTAGCAACAGGGAGATGAGCAACGTAGTTTTAAGCCTTGACGGCAGACAGGACGTCAATGACCGGATGCGTCCGTTCCGGAACGGCAGGGGAAGCTATGACCTGATAGTGCCGAAGTTCCAGAAATTTGCCAAAGAACGCGGTGACAGGGATTACTTTATCCGGGGGACCTTTACGAGAAATAACCTGGACTTTGCAGACGATGTGCTCCATTTTGCCGATCTTGGATTTGAAAAGATGTCGGTGGAGCCTGTGGTGGCCTCTCCGGAGGAACCCTATGCCATCCGGGAAGAAGACCTTCCGCAGATCATGGAGGAGTACGACAGGCTGGCTGAGGAATATATAAAGCGCCACAAAGAGGGAAGGGGCTTTACCTTTTTCCATTTTATGCTGGACTTGAACCAGGGGCCGTGCGTTGCGAAGCGGTTATCCGGCTGCGGTTCAGGAACCGAATACCTGGCTGTAACGCCATGGGGAGATCTCTACCCCTGTCATCAGTTTGTGGGAAATGAAGAATTTCTTCTCGGCAATGTGGACGAGGGTGTGACAAAGACGGAGATTTGTAATGAATTCAAGCTCTGTAATGTCTACGCAAAGGATAAATGCAGGGATTGTTTTGCGAGATTTTACTGCAGCGGCGGCTGTGCGGCCAATTCTTTTAATTTCCATGGCTCTATTACAGATGCTTATGATATCGGATGTGAAATGCAGAAAAAGCGGATCGAGTGTGCAATTATGATTAAAGCTGCTCTGGCTGAGGAAGAATAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 9697,
                "end": 9843,
                "strand": -1,
                "locus_tag": "MLALJMBA_02076",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">MLALJMBA_02076</span></strong><br>\n \n  hypothetical protein<br>\n \n <br>\n Locus tag: <span class=\"serif\">MLALJMBA_02076</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,697 - 9,843,\n (total: 147 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: SCIFF<br>\n \n  biosynthetic (rule-based-clusters) ranthipeptide: TIGR03973<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKHVKTLNTNTLKNSMKKGGCGECQTSCQSACKTSCTVGNQSCENQNR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=NZ_KE992908.1&amp;from=0&amp;to=9965\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKHVKTLNTNTLKNSMKKGGCGECQTSCQSACKTSCTVGNQSCENQNR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAACACGTTAAAACATTAAACACAAACACATTAAAAAACAGCATGAAGAAGGGCGGCTGCGGCGAGTGCCAGACATCCTGCCAGTCTGCATGTAAGACATCTTGTACAGTAGGAAACCAGAGCTGCGAGAATCAGAACCGATAA\">Copy to clipboard</span><br>\n</div>"
            }
        ],
        "clusters": [
            {
                "start": 8145,
                "end": 9843,
                "tool": "rule-based-clusters",
                "neighbouring_start": 0,
                "neighbouring_end": 9965,
                "product": "ranthipeptide",
                "height": 2,
                "kind": "protocluster",
                "prefix": ""
            }
        ],
        "ttaCodons": [],
        "type": "ranthipeptide",
        "products": [
            "ranthipeptide"
        ],
        "anchor": "r115c1"
    }
};
var details_data = {
    "nrpspks": {},
    "pfam": {}
};
var resultsData = {};
